#include <cstdlib>
#include <cstring>
#include <exception>
#include <iostream>
#include <stdexcept>
#include <string>
#include <string_view>
#include <vector>

#include "../xgetopt.h"

namespace test {

struct Failure : std::runtime_error {
	explicit Failure(const std::string& msg) : std::runtime_error(msg) {}
};

static int g_failed = 0;
static int g_passed = 0;

#define TOSTR2(x) #x
#define TOSTR(x) TOSTR2(x)

#define TEST_ASSERT(expr) \
	do { \
		if (!(expr)) throw ::test::Failure(std::string("ASSERT failed: ") + #expr + " @" + __FILE__ + ":" + TOSTR(__LINE__)); \
	} while (0)

#define TEST_EQ(a, b) \
	do { \
		auto _a = (a); \
		auto _b = (b); \
		if (!((_a) == (_b))) { \
			throw ::test::Failure(std::string("EQ failed: ") + #a + " == " + #b + " @" + __FILE__ + ":" + TOSTR(__LINE__)); \
		} \
	} while (0)

#define TEST_NE(a, b) \
	do { \
		auto _a = (a); \
		auto _b = (b); \
		if (((_a) == (_b))) { \
			throw ::test::Failure(std::string("NE failed: ") + #a + " != " + #b + " @" + __FILE__ + ":" + TOSTR(__LINE__)); \
		} \
	} while (0)

#define TEST_THROWS(stmt) \
	do { \
		bool threw = false; \
		try { (void)(stmt); } catch (...) { threw = true; } \
		if (!threw) throw ::test::Failure(std::string("THROWS failed: ") + #stmt + " @" + __FILE__ + ":" + TOSTR(__LINE__)); \
	} while (0)

#define TEST_NOTHROW(stmt) \
	do { \
		try { (void)(stmt); } catch (const std::exception& e) { \
			throw ::test::Failure(std::string("NOTHROW failed: ") + #stmt + " threw: " + e.what() + " @" + __FILE__ + ":" + TOSTR(__LINE__)); \
		} \
	} while (0)

struct ArgvBuilder {
	std::vector<std::string> storage;
	std::vector<char*> argv;

	explicit ArgvBuilder(std::initializer_list<std::string_view> args) {
		storage.reserve(args.size());
		argv.reserve(args.size() + 1);
		for (auto s : args) storage.emplace_back(s);
		for (auto& s : storage) argv.push_back(s.data());
		argv.push_back(nullptr);
	}

	int argc() const { return static_cast<int>(storage.size()); }
	char** data() { return argv.data(); }
};

static constexpr auto make_main_parser() {
	return XGetOpt::OptionParser<
		XGetOpt::Option<'h', "help", "help", XGetOpt::NoArgument>,
		XGetOpt::Option<'v', "verbose", "verbose", XGetOpt::NoArgument>,
		XGetOpt::Option<'o', "output", "output", XGetOpt::RequiredArgument, "file">,
		XGetOpt::Option<'p', "param", "param", XGetOpt::OptionalArgument>,
		XGetOpt::Option<1001, "long-only", "long-only", XGetOpt::NoArgument>,
		XGetOpt::Option<'s', "", "short-only", XGetOpt::NoArgument>,
		XGetOpt::Option<1002, "long-description", "This item has an extremely long description, which XGetOpt is expected to wrap at 80-character lines for easy display in a terminal. If it fails to do this, it is not functioning properly.", XGetOpt::RequiredArgument, "arg">,
		XGetOpt::Option<1003, "newline-description", "This description contains newlines.\nThese should\nbe preserved\nin the\nhelp string,\nand the\nnext line\nshould be\nindented to\nthe description column.", XGetOpt::NoArgument>
	>{};
}

static constexpr auto make_sub_parser() {
	return XGetOpt::OptionParser<
		XGetOpt::Option<'a', "alpha", "alpha", XGetOpt::NoArgument>,
		XGetOpt::Option<'b', "beta", "beta", XGetOpt::RequiredArgument, "value">
	>{};
}

static void test_help_string_smoke() {
	constexpr auto parser = make_main_parser();
	constexpr std::string_view help = parser.getHelpString();
	TEST_ASSERT(!help.empty());
	TEST_ASSERT(help.find("--help") != std::string_view::npos);
	TEST_ASSERT(help.find("--output") != std::string_view::npos);
}

static void test_help_string_lines_dont_exceed_80_chars() {
	constexpr auto parser = make_main_parser();
	constexpr std::string_view help = parser.getHelpString();

	size_t line_start = 0;
	while (line_start < help.size()) {
		size_t line_end = help.find('\n', line_start);
		if (line_end == std::string_view::npos) {
			line_end = help.size();
		}
		size_t line_length = line_end - line_start;
		TEST_ASSERT(line_length <= 80);
		line_start = line_end + 1;
	}
}

static void test_parse_short_and_long() {
	constexpr auto parser = make_main_parser();
	ArgvBuilder av{"prog", "-h", "--verbose", "--output", "out.txt"};
	auto seq = parser.parse(av.argc(), av.data());
	TEST_ASSERT(seq.hasOption('h'));
	TEST_ASSERT(seq.hasOption('v'));

	bool saw_output = false;
	for (const auto& opt : seq) {
		if (opt.getShortOpt() == 'o') {
			saw_output = true;
			TEST_ASSERT(opt.hasArgument());
			TEST_EQ(opt.getArgument(), std::string_view("out.txt"));
		}
	}
	TEST_ASSERT(saw_output);
}

static void test_parse_required_argument_forms() {
	constexpr auto parser = make_main_parser();

	{ // long form with '='
		ArgvBuilder av{"prog", "--output=out.txt"};
		auto seq = parser.parse(av.argc(), av.data());
		bool saw_output = false;
		for (const auto& opt : seq) {
			if (opt.getShortOpt() == 'o') {
				saw_output = true;
				TEST_ASSERT(opt.hasArgument());
				TEST_EQ(opt.getArgument(), std::string_view("out.txt"));
			}
		}
		TEST_ASSERT(saw_output);
	}

	{ // short form with attached arg
		ArgvBuilder av{"prog", "-oout.txt"};
		auto seq = parser.parse(av.argc(), av.data());
		bool saw_output = false;
		for (const auto& opt : seq) {
			if (opt.getShortOpt() == 'o') {
				saw_output = true;
				TEST_ASSERT(opt.hasArgument());
				TEST_EQ(opt.getArgument(), std::string_view("out.txt"));
			}
		}
		TEST_ASSERT(saw_output);
	}
}

static void test_parse_optional_argument() {
	constexpr auto parser = make_main_parser();

	{ // no argument
		ArgvBuilder av{"prog", "--param"};
		auto seq = parser.parse(av.argc(), av.data());
		bool saw = false;
		for (const auto& opt : seq) {
			if (opt.getShortOpt() == 'p') {
				saw = true;
				TEST_ASSERT(!opt.hasArgument());
			}
		}
		TEST_ASSERT(saw);
	}

	{ // with argument using =
		ArgvBuilder av{"prog", "--param=zzz"};
		auto seq = parser.parse(av.argc(), av.data());
		bool saw = false;
		for (const auto& opt : seq) {
			if (opt.getShortOpt() == 'p') {
				saw = true;
				TEST_ASSERT(opt.hasArgument());
				TEST_EQ(opt.getArgument(), std::string_view("zzz"));
			}
		}
		TEST_ASSERT(saw);
	}

	{ // long optional args typically only bind via '='; separate token becomes non-option
		ArgvBuilder av{"prog", "--param", "zzz"};
		auto seq = parser.parse(av.argc(), av.data());
		bool saw = false;
		for (const auto& opt : seq) {
			if (opt.getShortOpt() == 'p') {
				saw = true;
				TEST_ASSERT(!opt.hasArgument());
			}
		}
		TEST_ASSERT(saw);
		auto nonopts = seq.getNonOptionArguments();
		TEST_EQ(nonopts.size(), size_t{1});
		TEST_EQ(nonopts[0], std::string_view("zzz"));
	}
}

static void test_parse_long_only_and_short_only() {
	constexpr auto parser = make_main_parser();
	ArgvBuilder av{"prog", "--long-only", "-s"};
	auto seq = parser.parse(av.argc(), av.data());
	TEST_ASSERT(seq.hasOption(1001));
	TEST_ASSERT(seq.hasOption('s'));
}

static void test_option_clustering() {
	constexpr auto parser = make_main_parser();
	ArgvBuilder av{"prog", "-vh"};
	auto seq = parser.parse(av.argc(), av.data());
	TEST_ASSERT(seq.hasOption('v'));
	TEST_ASSERT(seq.hasOption('h'));
}

static void test_non_option_arguments_are_collected() {
	constexpr auto parser = make_main_parser();
	ArgvBuilder av{"prog", "file1", "-v", "file2"};
	auto seq = parser.parse(av.argc(), av.data());
	TEST_ASSERT(seq.hasOption('v'));
	auto nonopts = seq.getNonOptionArguments();
	TEST_EQ(nonopts.size(), size_t{2});
	TEST_EQ(nonopts[0], std::string_view("file1"));
	TEST_EQ(nonopts[1], std::string_view("file2"));
}

static void test_double_parse_resets_global_state() {
	constexpr auto parser = make_main_parser();
	ArgvBuilder av1{"prog", "-v"};
	ArgvBuilder av2{"prog", "-h"};

	auto s1 = parser.parse(av1.argc(), av1.data());
	auto s2 = parser.parse(av2.argc(), av2.data());
	TEST_ASSERT(s1.hasOption('v'));
	TEST_ASSERT(s2.hasOption('h'));
}

static void test_double_dash_collects_remaining_as_nonoptions() {
	constexpr auto parser = make_main_parser();
	ArgvBuilder av{"prog", "-v", "--", "file1", "-h"};
	auto seq = parser.parse(av.argc(), av.data());
	TEST_ASSERT(seq.hasOption('v'));

	// After `--`, everything is treated as positional arguments.
	auto nonopts = seq.getNonOptionArguments();
	TEST_EQ(nonopts.size(), size_t{2});
	TEST_EQ(nonopts[0], std::string_view("file1"));
	TEST_EQ(nonopts[1], std::string_view("-h"));
}

static void test_parse_until_before_first_nonoption_subcommand_pattern() {
	constexpr auto global = make_main_parser();
	constexpr auto sub = make_sub_parser();

	// global opts, then subcommand, then subcommand opts
	ArgvBuilder av{"prog", "-v", "subcmd", "-a", "--beta", "B"};
	auto [gopts, rem] = global.parse_until<XGetOpt::BeforeFirstNonOptionArgument>(av.argc(), av.data());
	TEST_ASSERT(gopts.hasOption('v'));

	// remainder should begin at the subcommand token
	TEST_ASSERT(rem.argc >= 1);
	TEST_EQ(std::string_view(rem.argv[0]), std::string_view("subcmd"));

	// Passing remainder directly should treat rem.argv[0] as argv[0] (program name)
	// and not skip the first option after subcmd.
	auto subopts = sub.parse(rem.argc, rem.argv);
	TEST_ASSERT(subopts.hasOption('a'));
	bool saw_beta = false;
	for (const auto& opt : subopts) {
		if (opt.getShortOpt() == 'b') {
			saw_beta = true;
			TEST_ASSERT(opt.hasArgument());
			TEST_EQ(opt.getArgument(), std::string_view("B"));
		}
	}
	TEST_ASSERT(saw_beta);
}

static void test_parse_until_after_first_nonoption_consumes_one_nonoption() {
	constexpr auto parser = make_main_parser();
	ArgvBuilder av{"prog", "-v", "cmd", "--output", "x"};

	auto [opts, rem] = parser.parse_until<XGetOpt::AfterFirstNonOptionArgument>(av.argc(), av.data());
	TEST_ASSERT(opts.hasOption('v'));

	// Exactly one non-option should be in parsed results.
	auto nonopts = opts.getNonOptionArguments();
	TEST_EQ(nonopts.size(), size_t{1});
	TEST_EQ(nonopts[0], std::string_view("cmd"));

	// remainder begins after cmd
	TEST_ASSERT(rem.argc >= 0);
	if (rem.argc >= 1) {
		TEST_EQ(std::string_view(rem.argv[0]), std::string_view("--output"));
	}
}

static void test_parse_throws_on_unknown_and_missing_arg() {
	constexpr auto parser = make_main_parser();
	{ // unknown
		ArgvBuilder av{"prog", "--does-not-exist"};
		TEST_THROWS(parser.parse(av.argc(), av.data()));
	}
	{ // missing required argument
		ArgvBuilder av{"prog", "--output"};
		TEST_THROWS(parser.parse(av.argc(), av.data()));
	}
}

static void test_parse_until_before_first_error_does_not_throw_and_returns_remainder() {
	constexpr auto parser = make_main_parser();

	{ // unknown option
		ArgvBuilder av{"prog", "-v", "--nope", "zzz"};
		auto [opts, rem] = parser.parse_until<XGetOpt::BeforeFirstError>(av.argc(), av.data());
		TEST_ASSERT(opts.hasOption('v'));
		TEST_ASSERT(rem.argc >= 1);
		TEST_EQ(std::string_view(rem.argv[0]), std::string_view("--nope"));
	}

	{ // missing required arg
		ArgvBuilder av{"prog", "--output"};
		auto [opts, rem] = parser.parse_until<XGetOpt::BeforeFirstError>(av.argc(), av.data());
		TEST_EQ(opts.size(), size_t{0});
		TEST_ASSERT(rem.argc >= 1);
		TEST_EQ(std::string_view(rem.argv[0]), std::string_view("--output"));
	}

	{ // clustered short options where the error occurs mid-token
		ArgvBuilder av{"prog", "-vz"}; // 'v' known, 'z' unknown
		auto [opts, rem] = parser.parse_until<XGetOpt::BeforeFirstError>(av.argc(), av.data());
		TEST_ASSERT(opts.hasOption('v'));
		TEST_ASSERT(rem.argc >= 1);
		TEST_EQ(std::string_view(rem.argv[0]), std::string_view("-vz"));
	}

	{ // clustered short options missing required argument (-o requires an arg)
		ArgvBuilder av{"prog", "-vo"};
		auto [opts, rem] = parser.parse_until<XGetOpt::BeforeFirstError>(av.argc(), av.data());
		TEST_ASSERT(opts.hasOption('v'));
		TEST_ASSERT(rem.argc >= 1);
		TEST_EQ(std::string_view(rem.argv[0]), std::string_view("-vo"));
	}
}

static void test_multiple_parse_and_combine() {
	// Effect: Stop after Nth non-option argument
	// Achieved by repeatedly parsing and combining the resulting OptionSequences.
	constexpr auto parser = make_main_parser();
	ArgvBuilder av{"prog", "-v", "file1", "--output", "out.txt", "file2", "-h"};
	auto total_opts = XGetOpt::OptionSequence{};
	int nonopt_count = 0;
	int argc = av.argc();
	char** argv = av.data();
	while (nonopt_count < 2) {
		auto [opts, rem] = parser.parse_until<XGetOpt::AfterFirstNonOptionArgument>(argc, argv);
		total_opts += opts;
		nonopt_count++;
		argc = rem.argc + 1;
		argv = rem.argv - 1; // Adjust to add an argv[0] that's ignored
			// This is unsafe generally and shouldn't be done in production code
			// In production, you would either want to:
			// 1. FIRST verify that rem.argv does NOT point to argv[0]
			// Or better, 2. Copy rem.argv into a new array with a proper, ignorable argv[0]
	}
	TEST_ASSERT(total_opts.hasOption('v'));
	TEST_ASSERT(!total_opts.hasOption('h'));
	bool saw_output = false;
	for (const auto& opt : total_opts) {
		if (opt.getShortOpt() == 'o') {
			saw_output = true;
			TEST_ASSERT(opt.hasArgument());
			TEST_EQ(opt.getArgument(), std::string_view("out.txt"));
		}
	}
	TEST_ASSERT(saw_output);

	// Two non-option arguments collected
	auto nonopts = total_opts.getNonOptionArguments();
	TEST_EQ(nonopts.size(), size_t{2});
	TEST_EQ(nonopts[0], std::string_view("file1"));
	TEST_EQ(nonopts[1], std::string_view("file2"));

	// Remaining args after two non-options should be "-h"
	TEST_ASSERT(argc >= 1);
	TEST_EQ(std::string_view(argv[1]), std::string_view("-h"));
}

static void test_ignore_errors_by_multiple_parse() {
	// Effect: Ignore all parsing errors
	// Achieved by repeatedly parsing with BeforeFirstError,
	// skipping the offending token each time,
	// and combining the resulting OptionSequences.
	constexpr auto parser = make_main_parser();
	ArgvBuilder av{"prog", "-v", "--nope", "-h", "--output", "out.txt", "--bad", "--output"};
	auto total_opts = XGetOpt::OptionSequence{};
	int argc = av.argc();
	char** argv = av.data();
	while (argc > 1) {
		auto [opts, rem] = parser.parse_until<XGetOpt::BeforeFirstError>(argc, argv);
		total_opts += opts;
		if (rem.argc == argc) {
			// No progress made; skip first token in remainder
			argc -= 1;
			argv += 1;
		} else {
			argc = rem.argc;
			argv = rem.argv;
		}
	}
	TEST_ASSERT(total_opts.hasOption('v'));
	TEST_ASSERT(total_opts.hasOption('h'));
	bool saw_output = false;
	for (const auto& opt : total_opts) {
		if (opt.getShortOpt() == 'o') {
			saw_output = true;
			TEST_ASSERT(opt.hasArgument());
			TEST_EQ(opt.getArgument(), std::string_view("out.txt"));
		}
	}
	TEST_ASSERT(saw_output);
	// No non-option arguments should be present
	auto nonopts = total_opts.getNonOptionArguments();
	TEST_EQ(nonopts.size(), size_t{0});
}

static void test_plus_not_recognized_as_option() {
	// XGetOpt prepends a '+' to the short options string to disable permutation and enforce POSIX-style parsing.
	// If a given platform's getopt_long implementation does not support this, then '+' will be treated as a normal option character,
	// which is not what we want. This test verifies that '+' is not treated as an option character.
	// If we encounter a platform on which this test fails, we will need to look for other ways to enforce
	// POSIX-style parsing on that platform.
	//
	// This test verifies that '-+' throws an unknown option error, and that the offending shortopt is '+'

	constexpr auto parser = make_main_parser();
	ArgvBuilder av{"prog", "-+"};

	TEST_THROWS(parser.parse(av.argc(), av.data()));

	auto [opts, rem] = parser.parse_until<XGetOpt::BeforeFirstError>(av.argc(), av.data());
	TEST_EQ(opts.size(), size_t{0});
	TEST_ASSERT(rem.argc >= 1);
	TEST_EQ(std::string_view(rem.argv[0]), std::string_view("-+"));
}

static void test_newlines_in_option_descriptions() {
	// Newlines in option descriptions should be preserved, and:
	// 1. The help string generator should not break lines in the middle of words when wrapping, but should break at whitespace.
	// 2. When a newline is encountered in the description, the next line should be indented to the description column,
	//  just like a normal line break for wrapping would be.

	constexpr auto parser = make_main_parser();
	constexpr std::string_view help = parser.getHelpString();
	TEST_ASSERT(!help.empty());

	auto split_lines = [](std::string_view s) {
		std::vector<std::string_view> out;
		size_t start = 0;
		while (start <= s.size()) {
			size_t end = s.find('\n', start);
			if (end == std::string_view::npos) end = s.size();
			out.push_back(s.substr(start, end - start));
			if (end == s.size()) break;
			start = end + 1;
		}
		while (!out.empty() && out.back().empty()) out.pop_back();
		return out;
	};

	auto is_space_prefix = [](std::string_view line, size_t count) {
		if (line.size() < count) return false;
		for (size_t i = 0; i < count; ++i) {
			if (line[i] != ' ') return false;
		}
		return true;
	};

	auto rstrip_spaces = [](std::string_view s) {
		while (!s.empty() && s.back() == ' ') s.remove_suffix(1);
		return s;
	};

	const auto lines = split_lines(help);
	TEST_ASSERT(!lines.empty());

	// --- (A) Newlines preserved + indented to the description column ---
	constexpr std::string_view expected_newline_desc =
		"This description contains newlines.\n"
		"These should\n"
		"be preserved\n"
		"in the\n"
		"help string,\n"
		"and the\n"
		"next line\n"
		"should be\n"
		"indented to\n"
		"the description column.";

	std::vector<std::string_view> expected_newline_lines;
	{
		size_t start = 0;
		while (start <= expected_newline_desc.size()) {
			size_t end = expected_newline_desc.find('\n', start);
			if (end == std::string_view::npos) end = expected_newline_desc.size();
			expected_newline_lines.push_back(expected_newline_desc.substr(start, end - start));
			if (end == expected_newline_desc.size()) break;
			start = end + 1;
		}
	}
	TEST_EQ(expected_newline_lines.size(), size_t{10});

	size_t newline_opt_line = std::string_view::npos;
	for (size_t i = 0; i < lines.size(); ++i) {
		if (lines[i].find("--newline-description") != std::string_view::npos) {
			newline_opt_line = i;
			break;
		}
	}
	TEST_NE(newline_opt_line, std::string_view::npos);

	const size_t desc_col = lines[newline_opt_line].find(expected_newline_lines[0]);
	TEST_NE(desc_col, std::string_view::npos);

	// First line contains the option label plus the first description line.
	TEST_EQ(rstrip_spaces(lines[newline_opt_line].substr(desc_col)), expected_newline_lines[0]);

	// Subsequent lines should be indented to the description column and match each newline-delimited segment exactly.
	for (size_t k = 1; k < expected_newline_lines.size(); ++k) {
		const size_t line_index = newline_opt_line + k;
		TEST_ASSERT(line_index < lines.size());
		const auto line = lines[line_index];
		TEST_ASSERT(is_space_prefix(line, desc_col));
		TEST_EQ(rstrip_spaces(line.substr(desc_col)), expected_newline_lines[k]);
	}

	// --- (B) Wrapping should not split words (validate by reconstruction) ---
	// We use the existing long-description option, which wraps at 80 columns.
	constexpr std::string_view expected_long_desc =
		"This item has an extremely long description, which XGetOpt is expected to wrap at 80-character lines for easy display in a terminal. If it fails to do this, it is not functioning properly.";

	size_t long_opt_line = std::string_view::npos;
	for (size_t i = 0; i < lines.size(); ++i) {
		if (lines[i].find("--long-description") != std::string_view::npos) {
			long_opt_line = i;
			break;
		}
	}
	TEST_NE(long_opt_line, std::string_view::npos);

	const size_t long_desc_col = lines[long_opt_line].find("This item has an extremely long description");
	TEST_NE(long_desc_col, std::string_view::npos);

	// Collect all wrapped lines for this description until the next option line begins.
	// In the current test parser, the next option after --long-description is --newline-description.
	std::vector<std::string_view> long_desc_lines;
	long_desc_lines.push_back(lines[long_opt_line].substr(long_desc_col));
	for (size_t i = long_opt_line + 1; i < lines.size(); ++i) {
		if (lines[i].find("--newline-description") != std::string_view::npos) break;
		if (!is_space_prefix(lines[i], long_desc_col)) break;
		long_desc_lines.push_back(lines[i].substr(long_desc_col));
	}
	TEST_ASSERT(long_desc_lines.size() >= 2); // should wrap at least once

	std::string reconstructed;
	for (size_t i = 0; i < long_desc_lines.size(); ++i) {
		if (i) reconstructed.push_back(' ');
		auto part = rstrip_spaces(long_desc_lines[i]);
		reconstructed.append(part.data(), part.size());
	}

	// If wrapping ever split a word, reconstructing with spaces would introduce a space inside that word.
	TEST_EQ(reconstructed, expected_long_desc);
}

static void run_test(const char* name, void (*fn)()) {
	try {
		fn();
		++g_passed;
		std::cout << "[PASS] " << name << "\n";
	} catch (const Failure& f) {
		++g_failed;
		std::cout << "[FAIL] " << name << ": " << f.what() << "\n";
	} catch (const std::exception& e) {
		++g_failed;
		std::cout << "[FAIL] " << name << ": unexpected exception: " << e.what() << "\n";
	} catch (...) {
		++g_failed;
		std::cout << "[FAIL] " << name << ": unknown exception\n";
	}
}

} // namespace test

int main() {
	using namespace test;

	run_test("help_string_smoke", test_help_string_smoke);
	run_test("help_string_lines_dont_exceed_80_chars", test_help_string_lines_dont_exceed_80_chars);
	run_test("parse_short_and_long", test_parse_short_and_long);
	run_test("parse_required_argument_forms", test_parse_required_argument_forms);
	run_test("parse_optional_argument", test_parse_optional_argument);
	run_test("parse_long_only_and_short_only", test_parse_long_only_and_short_only);
	run_test("option_clustering", test_option_clustering);
	run_test("non_option_arguments_are_collected", test_non_option_arguments_are_collected);
	run_test("double_parse_resets_global_state", test_double_parse_resets_global_state);
	run_test("double_dash_collects_remaining_as_nonoptions", test_double_dash_collects_remaining_as_nonoptions);
	run_test("parse_until_before_first_nonoption_subcommand_pattern", test_parse_until_before_first_nonoption_subcommand_pattern);
	run_test("parse_until_after_first_nonoption_consumes_one_nonoption", test_parse_until_after_first_nonoption_consumes_one_nonoption);
	run_test("multiple_parse_and_combine", test_multiple_parse_and_combine);
	run_test("parse_throws_on_unknown_and_missing_arg", test_parse_throws_on_unknown_and_missing_arg);
	run_test("parse_until_before_first_error", test_parse_until_before_first_error_does_not_throw_and_returns_remainder);
	run_test("ignore_errors_by_multiple_parse", test_ignore_errors_by_multiple_parse);
	run_test("plus_not_recognized_as_option", test_plus_not_recognized_as_option);
	run_test("newlines_in_option_descriptions", test_newlines_in_option_descriptions);

	std::cout << "\npassed: " << g_passed << ", failed: " << g_failed << "\n";
	return g_failed == 0 ? 0 : 1;
}
