#!/usr/bin/env bash
function bpp____repeat() {
	return $1
}
function bpp____dynamic__cast() {
	local __type="$1" __outputVar="$2" __this="$3"
	([[ -z "${__outputVar}" ]]) && >&2 echo "Bash++: Error: Invalid dynamic_cast" && exit 1
	eval "${__outputVar}=0"
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vTable="${__this}____vPointer"
	if ! eval "declare -p \"${__vTable}\"" &>/dev/null; then
		return 1
	fi
	while [[ ! -z "${!__vTable}" ]] 2>/dev/null; do
		[[ "${!__vTable}" == "bpp__${__type}____vTable" ]] && eval "${__outputVar}=\"${__this}\"" && return 0
		__vTable="${!__vTable}[\"__parent__\"]"
	done
	return 1
}
function bpp__Stack__toPrimitive() {
	local __this="$1"
	shift 1
	
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @Stack.toPrimitive on null object"
		return 1
	fi

	echo Stack Instance

}
function bpp__Stack__size() {
	local __this="$1"
	shift 1
	
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @Stack.size on null object"
		return 1
	fi

local __this__stack=${__this}__stack
local __this__stack____arrayIndexString=#${__this__stack}[@]
eval local __this__stack____arrayIndex="\${${__this__stack____arrayIndexString}}"

echo "${__this__stack____arrayIndex}"
____ret=$?
unset __this__stack
unset __this__stack____arrayIndexString
unset __this__stack____arrayIndex

bpp____repeat $____ret

}
function bpp__Stack__push() {
	local __this="$1"
	shift 1
	local value="$1"
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @Stack.push on null object"
		return 1
	fi

local __this__stack=${__this}__stack
____assignment0=("$value")

eval "${__this__stack}+=(\"\${____assignment0[@]}\")"

____ret=$?
unset __this__stack

unset ____assignment0

bpp____repeat $____ret

}
function bpp__Stack__pop() {
	local __this="$1"
	shift 1
	
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @Stack.pop on null object"
		return 1
	fi

if {
local __this__stack=${__this}__stack
local __this__stack____arrayIndexString=#${__this__stack}[@]
eval local __this__stack____arrayIndex="\${${__this__stack____arrayIndexString}}"

[[ ${__this__stack____arrayIndex} -gt 0 ]]
____ret=$?
unset __this__stack
unset __this__stack____arrayIndexString
unset __this__stack____arrayIndex

bpp____repeat $____ret
}; then
local __this__stack=${__this}__stack
local __this__stack____arrayIndexString=#${__this__stack}[@]
eval local __this__stack____arrayIndex="\${${__this__stack____arrayIndexString}}"
local __this__stack=${__this}__stack
local __this__stack____arrayIndexString=${__this__stack}[$((${__this__stack____arrayIndex} - 1))]
eval local __this__stack____arrayIndex="${__this__stack____arrayIndexString}"

echo "${!__this__stack____arrayIndex}"
____ret=$?
unset __this__stack
unset __this__stack____arrayIndexString
unset __this__stack____arrayIndex
unset __this__stack
unset __this__stack____arrayIndexString
unset __this__stack____arrayIndex

bpp____repeat $____ret
local __this__stack=${__this}__stack
local __this__stack=${__this}__stack
local __this__stack____arrayIndexString=#${__this__stack}[@]
eval local __this__stack____arrayIndex="\${${__this__stack____arrayIndexString}}"

unset ${__this__stack}[$((${__this__stack____arrayIndex} - 1))]
____ret=$?
unset __this__stack
unset __this__stack
unset __this__stack____arrayIndexString
unset __this__stack____arrayIndex

bpp____repeat $____ret
return 0

fi 
return 1


}
function bpp__Stack__top() {
	local __this="$1"
	shift 1
	
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @Stack.top on null object"
		return 1
	fi

if {
local __this__stack=${__this}__stack
local __this__stack____arrayIndexString=#${__this__stack}[@]
eval local __this__stack____arrayIndex="\${${__this__stack____arrayIndexString}}"

[[ ${__this__stack____arrayIndex} -gt 0 ]]
____ret=$?
unset __this__stack
unset __this__stack____arrayIndexString
unset __this__stack____arrayIndex

bpp____repeat $____ret
}; then
local __this__stack=${__this}__stack
local __this__stack____arrayIndexString=#${__this__stack}[@]
eval local __this__stack____arrayIndex="\${${__this__stack____arrayIndexString}}"
local __this__stack=${__this}__stack
local __this__stack____arrayIndexString=${__this__stack}[$((${__this__stack____arrayIndex} - 1))]
eval local __this__stack____arrayIndex="${__this__stack____arrayIndexString}"

echo "${!__this__stack____arrayIndex}"
____ret=$?
unset __this__stack
unset __this__stack____arrayIndexString
unset __this__stack____arrayIndex
unset __this__stack
unset __this__stack____arrayIndexString
unset __this__stack____arrayIndex

bpp____repeat $____ret
return 0

fi 
return 1


}
function bpp__Stack__clear() {
	local __this="$1"
	shift 1
	
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @Stack.clear on null object"
		return 1
	fi

local __this__stack=${__this}__stack

unset ${__this__stack}
____ret=$?
unset __this__stack

bpp____repeat $____ret

}
function bpp__Stack__empty() {
	local __this="$1"
	shift 1
	
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @Stack.empty on null object"
		return 1
	fi

if {
local __this__stack=${__this}__stack
local __this__stack____arrayIndexString=#${__this__stack}[@]
eval local __this__stack____arrayIndex="\${${__this__stack____arrayIndexString}}"

[[ ${__this__stack____arrayIndex} -eq 0 ]]
____ret=$?
unset __this__stack
unset __this__stack____arrayIndexString
unset __this__stack____arrayIndex

bpp____repeat $____ret
}; then
return 0

else
return 1

fi 

}
function bpp__Stack____copy() {
	local __this="$1"
	shift 1
	local __copyFromPtr="$1"
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @Stack.__copy on null object"
		return 1
	fi

bpp____dynamic__cast "Stack" "__dynamicCast0" __copyFromPtr
__copyFromPtr=${__dynamicCast0}
unset __dynamicCast0
if [[ ${__copyFromPtr} == 0 ]]; then
	>&2 echo "Bash++: Error: Stack: Attempted to copy between incompatible types."
	return 1
fi

	local ____copyFromPtr__stack="${__copyFromPtr}__stack"
	eval "${__this}__stack=\${!____copyFromPtr__stack}"



}
function bpp__Stack____new() {
	local __this="$1"
	shift 1
	
	
if [[ "${__this}" == "" ]]; then
	while : ; do
		__this="bpp__Stack__$RANDOM$RANDOM$RANDOM$RANDOM"
		local __unusedVar="${__this}____vPointer"
		[[ -z "${!__unusedVar+x}" ]] && break
	done
fi
	eval "${__this}____vPointer=bpp__Stack____vTable"

	eval "${__this}__stack=()"




echo "${__this}"

}
function bpp__Stack____delete() {
	local __this="$1"
	shift 1
	
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @Stack.__delete on null object"
		return 1
	fi


unset "${__this}__stack"


unset "${__this}____vPointer"

}
declare -A bpp__Stack____vTable
bpp__Stack____vTable["toPrimitive"]="bpp__Stack__toPrimitive"
bpp__Stack____vTable["size"]="bpp__Stack__size"
bpp__Stack____vTable["push"]="bpp__Stack__push"
bpp__Stack____vTable["pop"]="bpp__Stack__pop"
bpp__Stack____vTable["top"]="bpp__Stack__top"
bpp__Stack____vTable["clear"]="bpp__Stack__clear"
bpp__Stack____vTable["empty"]="bpp__Stack__empty"
bpp__Stack____vTable["__copy"]="bpp__Stack____copy"
bpp__Stack____vTable["__delete"]="bpp__Stack____delete"

