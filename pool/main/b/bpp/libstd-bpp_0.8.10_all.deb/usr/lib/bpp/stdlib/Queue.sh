#!/usr/bin/env bash
function bpp____repeat() {
	return $1
}
function bpp____dynamic__cast() {
	local __type="$1" __outputVar="$2" __this="$3"
	([[ -z "${__outputVar}" ]]) && >&2 echo "Bash++: Error: Invalid dynamic_cast" && exit 1
	eval "${__outputVar}=0"
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vTable="${__this}____vPointer"
	if ! eval "declare -p \"${__vTable}\"" &>/dev/null; then
		return 1
	fi
	while [[ ! -z "${!__vTable}" ]] 2>/dev/null; do
		[[ "${!__vTable}" == "bpp__${__type}____vTable" ]] && eval "${__outputVar}=\"${__this}\"" && return 0
		__vTable="${!__vTable}[\"__parent__\"]"
	done
	return 1
}
function bpp__QueueNode__toPrimitive() {
	local __this="$1"
	shift 1
	
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @QueueNode.toPrimitive on null object"
		return 1
	fi

	echo QueueNode Instance

}
function bpp__QueueNode____copy() {
	local __this="$1"
	shift 1
	local __copyFromPtr="$1"
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @QueueNode.__copy on null object"
		return 1
	fi

bpp____dynamic__cast "QueueNode" "__dynamicCast0" __copyFromPtr
__copyFromPtr=${__dynamicCast0}
unset __dynamicCast0
if [[ ${__copyFromPtr} == 0 ]]; then
	>&2 echo "Bash++: Error: QueueNode: Attempted to copy between incompatible types."
	return 1
fi

	local ____copyFromPtr__data="${__copyFromPtr}__data"
	eval "${__this}__data=\${!____copyFromPtr__data}"


	local ____copyFromPtr__next="${__copyFromPtr}__next"
	eval "${__this}__next=\${!____copyFromPtr__next}"


}
function bpp__QueueNode____new() {
	local __this="$1"
	shift 1
	
	
if [[ "${__this}" == "" ]]; then
	while : ; do
		__this="bpp__QueueNode__$RANDOM$RANDOM$RANDOM$RANDOM"
		local __unusedVar="${__this}____vPointer"
		[[ -z "${!__unusedVar+x}" ]] && break
	done
fi
	eval "${__this}____vPointer=bpp__QueueNode____vTable"

	local __objAssignment=
	eval "${__this}__data=\$__objAssignment"
	unset __objAssignment


	eval "${__this}__next=0"



echo "${__this}"

}
function bpp__QueueNode____delete() {
	local __this="$1"
	shift 1
	
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @QueueNode.__delete on null object"
		return 1
	fi


unset "${__this}__data"
unset "${__this}__next"
unset "${__this}____vPointer"

}
declare -A bpp__QueueNode____vTable
bpp__QueueNode____vTable["toPrimitive"]="bpp__QueueNode__toPrimitive"
bpp__QueueNode____vTable["__copy"]="bpp__QueueNode____copy"
bpp__QueueNode____vTable["__delete"]="bpp__QueueNode____delete"

function bpp____initsupershell() {
	local bpp____supershellDirectory="/dev/shm/"
	if [[ ! -d "${bpp____supershellDirectory}" ]]; then
		bpp____supershellDirectory="${TMPDIR:-/tmp/}"
	fi
	local bpp____supershelltempfile="$(mktemp "${bpp____supershellDirectory}/XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX")"
	eval "exec {bpp____supershellFD__$BASHPID}<>\"$bpp____supershelltempfile\""
	rm "$bpp____supershelltempfile"
}
function bpp____supershell() {
	local __outputVar="$1" __command="$2" __supershellFD="bpp____supershellFD__$BASHPID" __temporaryStorage=""
	if [[ -z "${!__supershellFD}" ]]; then
		bpp____initsupershell
	else
		__temporaryStorage=$(< "/dev/fd/${!__supershellFD}")
	fi
	$__command 1>"/dev/fd/${!__supershellFD}"
	eval "$__outputVar=\$(< "/dev/fd/${!__supershellFD}")"
	echo "${__temporaryStorage}">"/dev/fd/${!__supershellFD}"
}
function bpp____vTable__lookup() {
	local __this="$1" __method="$2" __outputVar="$3"
	([[ -z "${__this}" ]] || [[ -z "${__method}" ]] || [[ -z "${__outputVar}" ]]) && >&2 echo "Bash++: Error: Invalid vTable lookup" && exit 1
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vTable="${__this}____vPointer"
	if ! eval "declare -p \"${__vTable}\"" &>/dev/null; then
		return 1
	fi
	local __result="${!__vTable}[\"${__method}\"]"
	[[ -z "${!__result}" ]] && >&2 echo "Bash++: Error: Method '${__method}' not found in vTable for object '${__this}'" && return 1
	eval "${__outputVar}=\$__result"
}
function bpp__Queue__toPrimitive() {
	local __this="$1"
	shift 1
	
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @Queue.toPrimitive on null object"
		return 1
	fi

	echo Queue Instance

}
function bpp__Queue__size() {
	local __this="$1"
	shift 1
	
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @Queue.size on null object"
		return 1
	fi

local __this__queueSize=${__this}__queueSize

echo "${!__this__queueSize}"
____ret=$?
unset __this__queueSize

bpp____repeat $____ret

}
function bpp__Queue__empty() {
	local __this="$1"
	shift 1
	
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @Queue.empty on null object"
		return 1
	fi

if {
local __this__queueSize=${__this}__queueSize

[[ ${!__this__queueSize} -eq 0 ]]
____ret=$?
unset __this__queueSize

bpp____repeat $____ret
}; then
return 0

else
return 1

fi 

}
function bpp__Queue__enqueue() {
	local __this="$1"
	shift 1
	local value="$1"
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @Queue.enqueue on null object"
		return 1
	fi

function ____supershellRunFunc0() {
	bpp__QueueNode____new
}
bpp____supershell ____supershellOutput0 ____supershellRunFunc0
__newAssignment0=${____supershellOutput0}
local bpp____ptr__3__QueueNode__node=${__newAssignment0}

unset __newAssignment0
unset -f ____supershellRunFunc0
unset ____supershellOutput0
local bpp____ptr__3__QueueNode__node__data=${bpp____ptr__3__QueueNode__node}__data
____assignment1="$value"

eval ${bpp____ptr__3__QueueNode__node__data}=\$____assignment1

____ret=$?
unset bpp____ptr__3__QueueNode__node__data
unset ____assignment1

bpp____repeat $____ret
if {
local __this__queueSize=${__this}__queueSize

[[ ${!__this__queueSize} -eq 0 ]]
____ret=$?
unset __this__queueSize

bpp____repeat $____ret
}; then
local __this__head=${__this}__head
____assignment2=${bpp____ptr__3__QueueNode__node}

eval ${__this__head}=\$____assignment2

____ret=$?
unset __this__head
unset ____assignment2

bpp____repeat $____ret
local __this__tail=${__this}__tail
____assignment3=${bpp____ptr__3__QueueNode__node}

eval ${__this__tail}=\$____assignment3

____ret=$?
unset __this__tail
unset ____assignment3

bpp____repeat $____ret
else
local __this__tail=${__this}__tail
local __this__tail__next=${!__this__tail}__next
____assignment4=${bpp____ptr__3__QueueNode__node}

eval ${__this__tail__next}=\$____assignment4

____ret=$?
unset __this__tail
unset __this__tail__next
unset ____assignment4

bpp____repeat $____ret
local __this__tail=${__this}__tail
____assignment5=${bpp____ptr__3__QueueNode__node}

eval ${__this__tail}=\$____assignment5

____ret=$?
unset __this__tail
unset ____assignment5

bpp____repeat $____ret
fi 
local __this__queueSize=${__this}__queueSize
local __this__queueSize=${__this}__queueSize
____assignment6=$((${!__this__queueSize} + 1))

eval ${__this__queueSize}=\$____assignment6

____ret=$?
unset __this__queueSize
unset __this__queueSize
unset ____assignment6

bpp____repeat $____ret

}
function bpp__Queue__dequeue() {
	local __this="$1"
	shift 1
	
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @Queue.dequeue on null object"
		return 1
	fi

if {
local __this__queueSize=${__this}__queueSize

[[ ${!__this__queueSize} -gt 0 ]]
____ret=$?
unset __this__queueSize

bpp____repeat $____ret
}; then
local __this__head=${__this}__head
local bpp____ptr__4__QueueNode__node=${!__this__head}

unset __this__head
local __this__head=${__this}__head
local __this__head=${__this}__head
local __this__head__next=${!__this__head}__next
____assignment7=${!__this__head__next}

eval ${__this__head}=\$____assignment7

____ret=$?
unset __this__head
unset __this__head
unset __this__head__next
unset ____assignment7

bpp____repeat $____ret
local __this__queueSize=${__this}__queueSize
local __this__queueSize=${__this}__queueSize
____assignment8=$((${!__this__queueSize} - 1))

eval ${__this__queueSize}=\$____assignment8

____ret=$?
unset __this__queueSize
unset __this__queueSize
unset ____assignment8

bpp____repeat $____ret
local bpp____ptr__4__QueueNode__node__data=${bpp____ptr__4__QueueNode__node}__data

echo "${!bpp____ptr__4__QueueNode__node__data}"
____ret=$?
unset bpp____ptr__4__QueueNode__node__data

bpp____repeat $____ret

if bpp____vTable__lookup "bpp____ptr__4__QueueNode__node${bpp____ptr__4__QueueNode__node}" "__delete" __func0; then

	${!__func0} bpp____ptr__4__QueueNode__node${bpp____ptr__4__QueueNode__node}
	unset __func0
fi


return 0

fi 
return 1


}
function bpp__Queue__front() {
	local __this="$1"
	shift 1
	
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @Queue.front on null object"
		return 1
	fi

if {
local __this__queueSize=${__this}__queueSize

[[ ${!__this__queueSize} -gt 0 ]]
____ret=$?
unset __this__queueSize

bpp____repeat $____ret
}; then
local __this__head=${__this}__head
local __this__head__data=${!__this__head}__data

echo "${!__this__head__data}"
____ret=$?
unset __this__head
unset __this__head__data

bpp____repeat $____ret
return 0

fi 
return 1


}
function bpp__Queue__back() {
	local __this="$1"
	shift 1
	
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @Queue.back on null object"
		return 1
	fi

if {
local __this__queueSize=${__this}__queueSize

[[ ${!__this__queueSize} -gt 0 ]]
____ret=$?
unset __this__queueSize

bpp____repeat $____ret
}; then
local __this__tail=${__this}__tail
local __this__tail__data=${!__this__tail}__data

echo "${!__this__tail__data}"
____ret=$?
unset __this__tail
unset __this__tail__data

bpp____repeat $____ret
return 0

fi 
return 1


}
function bpp__Queue__clear() {
	local __this="$1"
	shift 1
	
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @Queue.clear on null object"
		return 1
	fi

local __this__queueSize=${__this}__queueSize

local size=${!__this__queueSize}
____ret=$?
unset __this__queueSize

bpp____repeat $____ret
while [[ $size -gt 0 ]]; do
if bpp____vTable__lookup "${__this}" "dequeue" __func1; then

	${!__func1} ${__this} > /dev/null
____ret=$?
	unset __func1
fi

bpp____repeat $____ret
size=$((size - 1))


done

}
function bpp__Queue____copy() {
	local __this="$1"
	shift 1
	local __copyFromPtr="$1"
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @Queue.__copy on null object"
		return 1
	fi

bpp____dynamic__cast "Queue" "__dynamicCast1" __copyFromPtr
__copyFromPtr=${__dynamicCast1}
unset __dynamicCast1
if [[ ${__copyFromPtr} == 0 ]]; then
	>&2 echo "Bash++: Error: Queue: Attempted to copy between incompatible types."
	return 1
fi

	local ____copyFromPtr__head="${__copyFromPtr}__head"
	eval "${__this}__head=\${!____copyFromPtr__head}"


	local ____copyFromPtr__tail="${__copyFromPtr}__tail"
	eval "${__this}__tail=\${!____copyFromPtr__tail}"


	local ____copyFromPtr__queueSize="${__copyFromPtr}__queueSize"
	eval "${__this}__queueSize=\${!____copyFromPtr__queueSize}"


}
function bpp__Queue____new() {
	local __this="$1"
	shift 1
	
	
if [[ "${__this}" == "" ]]; then
	while : ; do
		__this="bpp__Queue__$RANDOM$RANDOM$RANDOM$RANDOM"
		local __unusedVar="${__this}____vPointer"
		[[ -z "${!__unusedVar+x}" ]] && break
	done
fi
	eval "${__this}____vPointer=bpp__Queue____vTable"

	eval "${__this}__head=0"


	eval "${__this}__tail=0"


	local __objAssignment=0
	eval "${__this}__queueSize=\$__objAssignment"
	unset __objAssignment



echo "${__this}"

}
function bpp__Queue____delete() {
	local __this="$1"
	shift 1
	
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @Queue.__delete on null object"
		return 1
	fi


unset "${__this}__head"
unset "${__this}__tail"
unset "${__this}__queueSize"
unset "${__this}____vPointer"

}
declare -A bpp__Queue____vTable
bpp__Queue____vTable["toPrimitive"]="bpp__Queue__toPrimitive"
bpp__Queue____vTable["size"]="bpp__Queue__size"
bpp__Queue____vTable["empty"]="bpp__Queue__empty"
bpp__Queue____vTable["enqueue"]="bpp__Queue__enqueue"
bpp__Queue____vTable["dequeue"]="bpp__Queue__dequeue"
bpp__Queue____vTable["front"]="bpp__Queue__front"
bpp__Queue____vTable["back"]="bpp__Queue__back"
bpp__Queue____vTable["clear"]="bpp__Queue__clear"
bpp__Queue____vTable["__copy"]="bpp__Queue____copy"
bpp__Queue____vTable["__delete"]="bpp__Queue____delete"

