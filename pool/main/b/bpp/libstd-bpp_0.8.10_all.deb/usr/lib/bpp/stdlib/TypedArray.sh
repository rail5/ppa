#!/usr/bin/env bash
function bpp____repeat() {
	return $1
}
function bpp____dynamic__cast() {
	local __type="$1" __outputVar="$2" __this="$3"
	([[ -z "${__outputVar}" ]]) && >&2 echo "Bash++: Error: Invalid dynamic_cast" && exit 1
	eval "${__outputVar}=0"
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vTable="${__this}____vPointer"
	if ! eval "declare -p \"${__vTable}\"" &>/dev/null; then
		return 1
	fi
	while [[ ! -z "${!__vTable}" ]] 2>/dev/null; do
		[[ "${!__vTable}" == "bpp__${__type}____vTable" ]] && eval "${__outputVar}=\"${__this}\"" && return 0
		__vTable="${!__vTable}[\"__parent__\"]"
	done
	return 1
}
function bpp__Array__toPrimitive() {
	local __this="$1"
	shift 1
	
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @Array.toPrimitive on null object"
		return 1
	fi

	echo Array Instance

}
function bpp__Array__size() {
	local __this="$1"
	shift 1
	
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @Array.size on null object"
		return 1
	fi

local __this__array=${__this}__array
local __this__array____arrayIndexString=#${__this__array}[@]
eval local __this__array____arrayIndex="\${${__this__array____arrayIndexString}}"

echo "${__this__array____arrayIndex}"
____ret=$?
unset __this__array
unset __this__array____arrayIndexString
unset __this__array____arrayIndex

bpp____repeat $____ret

}
function bpp__Array__push() {
	local __this="$1"
	shift 1
	local value="$1"
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @Array.push on null object"
		return 1
	fi

local __this__array=${__this}__array
____assignment0=("$value")

eval "${__this__array}+=(\"\${____assignment0[@]}\")"

____ret=$?
unset __this__array

unset ____assignment0

bpp____repeat $____ret

}
function bpp__Array__pop() {
	local __this="$1"
	shift 1
	
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @Array.pop on null object"
		return 1
	fi

if {
local __this__array=${__this}__array
local __this__array____arrayIndexString=#${__this__array}[@]
eval local __this__array____arrayIndex="\${${__this__array____arrayIndexString}}"

[[ ${__this__array____arrayIndex} -gt 0 ]]
____ret=$?
unset __this__array
unset __this__array____arrayIndexString
unset __this__array____arrayIndex

bpp____repeat $____ret
}; then
local __this__array=${__this}__array
local __this__array____arrayIndexString=${__this__array}[-1]
eval local __this__array____arrayIndex="${__this__array____arrayIndexString}"

echo "${!__this__array____arrayIndex}"
____ret=$?
unset __this__array
unset __this__array____arrayIndexString
unset __this__array____arrayIndex

bpp____repeat $____ret
local __this__array=${__this}__array

unset ${__this__array}[-1]
____ret=$?
unset __this__array

bpp____repeat $____ret
else
return 1

fi 

}
function bpp__Array__insert() {
	local __this="$1"
	shift 1
	local index="$1" value="$2"
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @Array.insert on null object"
		return 1
	fi

if {
local __this__array=${__this}__array
local __this__array____arrayIndexString=#${__this__array}[@]
eval local __this__array____arrayIndex="\${${__this__array____arrayIndexString}}"

[[ $index -lt 0 || $index -gt ${__this__array____arrayIndex} ]]
____ret=$?
unset __this__array
unset __this__array____arrayIndexString
unset __this__array____arrayIndex

bpp____repeat $____ret
}; then
return 1

fi 
local __this__array=${__this}__array
local __this__array____arrayIndexString=${__this__array}[@]
eval local __this__array____arrayIndex="${__this__array____arrayIndexString}"

local array_copy=("${!__this__array____arrayIndex}")
____ret=$?

unset __this__array
unset __this__array____arrayIndexString
unset __this__array____arrayIndex

bpp____repeat $____ret
local __this__array=${__this}__array
____assignment1=("${array_copy[@]:0:$index}" "$value" "${array_copy[@]:$index}")

eval "${__this__array}=(\"\${____assignment1[@]}\")"

____ret=$?
unset __this__array

unset ____assignment1

bpp____repeat $____ret

}
function bpp__Array__remove() {
	local __this="$1"
	shift 1
	local index="$1"
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @Array.remove on null object"
		return 1
	fi

if {
local __this__array=${__this}__array
local __this__array____arrayIndexString=#${__this__array}[@]
eval local __this__array____arrayIndex="\${${__this__array____arrayIndexString}}"

[[ $index -lt 0 || $index -ge ${__this__array____arrayIndex} ]]
____ret=$?
unset __this__array
unset __this__array____arrayIndexString
unset __this__array____arrayIndex

bpp____repeat $____ret
}; then
return 1

fi 
local __this__array=${__this}__array
local __this__array____arrayIndexString=${__this__array}[@]
eval local __this__array____arrayIndex="${__this__array____arrayIndexString}"

local array_copy=("${!__this__array____arrayIndex}")
____ret=$?

unset __this__array
unset __this__array____arrayIndexString
unset __this__array____arrayIndex

bpp____repeat $____ret
local __this__array=${__this}__array
____assignment2=("${array_copy[@]:0:$index}" "${array_copy[@]:$((index + 1))}")

eval "${__this__array}=(\"\${____assignment2[@]}\")"

____ret=$?
unset __this__array

unset ____assignment2

bpp____repeat $____ret

}
function bpp__Array__at() {
	local __this="$1"
	shift 1
	local index="$1"
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @Array.at on null object"
		return 1
	fi

local __this__array=${__this}__array
local __this__array____arrayIndexString=${__this__array}[$index]
eval local __this__array____arrayIndex="${__this__array____arrayIndexString}"

echo "${!__this__array____arrayIndex}"
____ret=$?
unset __this__array
unset __this__array____arrayIndexString
unset __this__array____arrayIndex

bpp____repeat $____ret

}
function bpp__Array__front() {
	local __this="$1"
	shift 1
	
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @Array.front on null object"
		return 1
	fi

if {
local __this__array=${__this}__array
local __this__array____arrayIndexString=#${__this__array}[@]
eval local __this__array____arrayIndex="\${${__this__array____arrayIndexString}}"

[[ ${__this__array____arrayIndex} -gt 0 ]]
____ret=$?
unset __this__array
unset __this__array____arrayIndexString
unset __this__array____arrayIndex

bpp____repeat $____ret
}; then
local __this__array=${__this}__array
local __this__array____arrayIndexString=${__this__array}[0]
eval local __this__array____arrayIndex="${__this__array____arrayIndexString}"

echo "${!__this__array____arrayIndex}"
____ret=$?
unset __this__array
unset __this__array____arrayIndexString
unset __this__array____arrayIndex

bpp____repeat $____ret
else
return 1

fi 

}
function bpp__Array__back() {
	local __this="$1"
	shift 1
	
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @Array.back on null object"
		return 1
	fi

if {
local __this__array=${__this}__array
local __this__array____arrayIndexString=#${__this__array}[@]
eval local __this__array____arrayIndex="\${${__this__array____arrayIndexString}}"

[[ ${__this__array____arrayIndex} -gt 0 ]]
____ret=$?
unset __this__array
unset __this__array____arrayIndexString
unset __this__array____arrayIndex

bpp____repeat $____ret
}; then
local __this__array=${__this}__array
local __this__array____arrayIndexString=${__this__array}[-1]
eval local __this__array____arrayIndex="${__this__array____arrayIndexString}"

echo "${!__this__array____arrayIndex}"
____ret=$?
unset __this__array
unset __this__array____arrayIndexString
unset __this__array____arrayIndex

bpp____repeat $____ret
else
return 1

fi 

}
function bpp__Array__all() {
	local __this="$1"
	shift 1
	
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @Array.all on null object"
		return 1
	fi

if {
local __this__array=${__this}__array
local __this__array____arrayIndexString=#${__this__array}[@]
eval local __this__array____arrayIndex="\${${__this__array____arrayIndexString}}"

[[ ${__this__array____arrayIndex} -gt 0 ]]
____ret=$?
unset __this__array
unset __this__array____arrayIndexString
unset __this__array____arrayIndex

bpp____repeat $____ret
}; then
local __this__array=${__this}__array
local __this__array____arrayIndexString=${__this__array}[@]
eval local __this__array____arrayIndex="${__this__array____arrayIndexString}"

echo "${!__this__array____arrayIndex}"
____ret=$?
unset __this__array
unset __this__array____arrayIndexString
unset __this__array____arrayIndex

bpp____repeat $____ret
else
return 1

fi 

}
function bpp__Array__empty() {
	local __this="$1"
	shift 1
	
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @Array.empty on null object"
		return 1
	fi

if {
local __this__array=${__this}__array
local __this__array____arrayIndexString=#${__this__array}[@]
eval local __this__array____arrayIndex="\${${__this__array____arrayIndexString}}"

[[ ${__this__array____arrayIndex} -eq 0 ]]
____ret=$?
unset __this__array
unset __this__array____arrayIndexString
unset __this__array____arrayIndex

bpp____repeat $____ret
}; then
return 0

else
return 1

fi 

}
function bpp__Array__slice() {
	local __this="$1"
	shift 1
	local start="$1" end="$2"
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @Array.slice on null object"
		return 1
	fi

if {
local __this__array=${__this}__array
local __this__array____arrayIndexString=#${__this__array}[@]
eval local __this__array____arrayIndex="\${${__this__array____arrayIndexString}}"

[[ $start -gt $end || ${__this__array____arrayIndex} -eq 0 ]]
____ret=$?
unset __this__array
unset __this__array____arrayIndexString
unset __this__array____arrayIndex

bpp____repeat $____ret
}; then
return 1

fi 
if {
[[ $start -lt 0 ]]
}; then
start=0

fi 
if {
local __this__array=${__this}__array
local __this__array____arrayIndexString=#${__this__array}[@]
eval local __this__array____arrayIndex="\${${__this__array____arrayIndexString}}"

[[ $end -ge ${__this__array____arrayIndex} ]]
____ret=$?
unset __this__array
unset __this__array____arrayIndexString
unset __this__array____arrayIndex

bpp____repeat $____ret
}; then
local __this__array=${__this}__array
local __this__array____arrayIndexString=#${__this__array}[@]
eval local __this__array____arrayIndex="\${${__this__array____arrayIndexString}}"

end=$((${__this__array____arrayIndex} - 1))
____ret=$?
unset __this__array
unset __this__array____arrayIndexString
unset __this__array____arrayIndex

bpp____repeat $____ret
fi 
local __this__array=${__this}__array
local __this__array____arrayIndexString=${__this__array}[@]
eval local __this__array____arrayIndex="${__this__array____arrayIndexString}"

local array_copy=("${!__this__array____arrayIndex}")
____ret=$?

unset __this__array
unset __this__array____arrayIndexString
unset __this__array____arrayIndex

bpp____repeat $____ret
echo "${array_copy[@]:$start:$((end - start + 1))}"


}
function bpp__Array__clear() {
	local __this="$1"
	shift 1
	
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @Array.clear on null object"
		return 1
	fi

local __this__array=${__this}__array

unset ${__this__array}
____ret=$?
unset __this__array

bpp____repeat $____ret

}
function bpp__Array____copy() {
	local __this="$1"
	shift 1
	local __copyFromPtr="$1"
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @Array.__copy on null object"
		return 1
	fi

bpp____dynamic__cast "Array" "__dynamicCast0" __copyFromPtr
__copyFromPtr=${__dynamicCast0}
unset __dynamicCast0
if [[ ${__copyFromPtr} == 0 ]]; then
	>&2 echo "Bash++: Error: Array: Attempted to copy between incompatible types."
	return 1
fi

	local ____copyFromPtr__array="${__copyFromPtr}__array"
	eval "${__this}__array=\${!____copyFromPtr__array}"



}
function bpp__Array____new() {
	local __this="$1"
	shift 1
	
	
if [[ "${__this}" == "" ]]; then
	while : ; do
		__this="bpp__Array__$RANDOM$RANDOM$RANDOM$RANDOM"
		local __unusedVar="${__this}____vPointer"
		[[ -z "${!__unusedVar+x}" ]] && break
	done
fi
	eval "${__this}____vPointer=bpp__Array____vTable"

	eval "${__this}__array=()"




echo "${__this}"

}
function bpp__Array____delete() {
	local __this="$1"
	shift 1
	
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @Array.__delete on null object"
		return 1
	fi


unset "${__this}__array"


unset "${__this}____vPointer"

}
declare -A bpp__Array____vTable
bpp__Array____vTable["toPrimitive"]="bpp__Array__toPrimitive"
bpp__Array____vTable["size"]="bpp__Array__size"
bpp__Array____vTable["push"]="bpp__Array__push"
bpp__Array____vTable["pop"]="bpp__Array__pop"
bpp__Array____vTable["insert"]="bpp__Array__insert"
bpp__Array____vTable["remove"]="bpp__Array__remove"
bpp__Array____vTable["at"]="bpp__Array__at"
bpp__Array____vTable["front"]="bpp__Array__front"
bpp__Array____vTable["back"]="bpp__Array__back"
bpp__Array____vTable["all"]="bpp__Array__all"
bpp__Array____vTable["empty"]="bpp__Array__empty"
bpp__Array____vTable["slice"]="bpp__Array__slice"
bpp__Array____vTable["clear"]="bpp__Array__clear"
bpp__Array____vTable["__copy"]="bpp__Array____copy"
bpp__Array____vTable["__delete"]="bpp__Array____delete"

function bpp__TypedArray__toPrimitive() {
	local __this="$1"
	shift 1
	
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @TypedArray.toPrimitive on null object"
		return 1
	fi

	echo TypedArray Instance

}
function bpp__TypedArray__set_type() {
	local __this="$1"
	shift 1
	local type="$1"
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @TypedArray.set_type on null object"
		return 1
	fi

if {
local __this__used=${__this}__used

[[ ${!__this__used} -ne 0 ]]
____ret=$?
unset __this__used

bpp____repeat $____ret
}; then
>& 2 echo "Error: TypedArray: Cannot change type after the array has been used."

return 1

fi 
local __this__type=${__this}__type
____assignment3="$type"

eval ${__this__type}=\$____assignment3

____ret=$?
unset __this__type
unset ____assignment3

bpp____repeat $____ret

}
function bpp__TypedArray___check_type() {
	local __this="$1"
	shift 1
	local value="$1"
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @TypedArray._check_type on null object"
		return 1
	fi

local __this__type=${__this}__type
bpp____dynamic__cast "${!__this__type}" "__dynamicCast1" "$value"

local check=${__dynamicCast1}
____ret=$?
unset __this__type
unset __dynamicCast1

bpp____repeat $____ret
if {
[[ "$check" == 0 ]]
}; then
local __this__type=${__this}__type

>& 2 echo "Error: TypedArray: Value '$value' is not of type '${!__this__type}'."
____ret=$?
unset __this__type

bpp____repeat $____ret
return 1

fi 
return 0


}
function bpp__TypedArray__push() {
	local __this="$1"
	shift 1
	local value="$1"
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @TypedArray.push on null object"
		return 1
	fi

local __this__used=${__this}__used
____assignment4=1

eval ${__this__used}=\$____assignment4

____ret=$?
unset __this__used
unset ____assignment4

bpp____repeat $____ret
if {
bpp__TypedArray___check_type ${__this} "$value"
}; then
bpp__Array__push ${__this} "$value"

else
return 1

fi 

}
function bpp__TypedArray__insert() {
	local __this="$1"
	shift 1
	local index="$1" value="$2"
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @TypedArray.insert on null object"
		return 1
	fi

local __this__used=${__this}__used
____assignment5=1

eval ${__this__used}=\$____assignment5

____ret=$?
unset __this__used
unset ____assignment5

bpp____repeat $____ret
if {
bpp__TypedArray___check_type ${__this} "$value"
}; then
if {
local __this__array=${__this}__array
local __this__array____arrayIndexString=#${__this__array}[@]
eval local __this__array____arrayIndex="\${${__this__array____arrayIndexString}}"

[[ $index -lt 0 || $index -gt ${__this__array____arrayIndex} ]]
____ret=$?
unset __this__array
unset __this__array____arrayIndexString
unset __this__array____arrayIndex

bpp____repeat $____ret
}; then
return 1

fi 
bpp__Array__insert ${__this} "$index" "$value"

else
return 1

fi 

}
function bpp__TypedArray____copy() {
	local __this="$1"
	shift 1
	local __copyFromPtr="$1"
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @TypedArray.__copy on null object"
		return 1
	fi

bpp____dynamic__cast "TypedArray" "__dynamicCast2" __copyFromPtr
__copyFromPtr=${__dynamicCast2}
unset __dynamicCast2
if [[ ${__copyFromPtr} == 0 ]]; then
	>&2 echo "Bash++: Error: TypedArray: Attempted to copy between incompatible types."
	return 1
fi

	local ____copyFromPtr__array="${__copyFromPtr}__array"
	eval "${__this}__array=\${!____copyFromPtr__array}"



	local ____copyFromPtr__type="${__copyFromPtr}__type"
	eval "${__this}__type=\${!____copyFromPtr__type}"


	local ____copyFromPtr__used="${__copyFromPtr}__used"
	eval "${__this}__used=\${!____copyFromPtr__used}"


}
function bpp__TypedArray____new() {
	local __this="$1"
	shift 1
	
	
if [[ "${__this}" == "" ]]; then
	while : ; do
		__this="bpp__TypedArray__$RANDOM$RANDOM$RANDOM$RANDOM"
		local __unusedVar="${__this}____vPointer"
		[[ -z "${!__unusedVar+x}" ]] && break
	done
fi
	eval "${__this}____vPointer=bpp__TypedArray____vTable"

	eval "${__this}__array=()"



	local __objAssignment=""
	eval "${__this}__type=\$__objAssignment"
	unset __objAssignment


	local __objAssignment=0
	eval "${__this}__used=\$__objAssignment"
	unset __objAssignment



echo "${__this}"

}
function bpp__TypedArray____delete() {
	local __this="$1"
	shift 1
	
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @TypedArray.__delete on null object"
		return 1
	fi


unset "${__this}__array"


unset "${__this}__type"
unset "${__this}__used"
unset "${__this}____vPointer"

}
declare -A bpp__TypedArray____vTable
bpp__TypedArray____vTable["__parent__"]="bpp__Array____vTable"
bpp__TypedArray____vTable["toPrimitive"]="bpp__TypedArray__toPrimitive"
bpp__TypedArray____vTable["size"]="bpp__Array__size"
bpp__TypedArray____vTable["pop"]="bpp__Array__pop"
bpp__TypedArray____vTable["remove"]="bpp__Array__remove"
bpp__TypedArray____vTable["at"]="bpp__Array__at"
bpp__TypedArray____vTable["front"]="bpp__Array__front"
bpp__TypedArray____vTable["back"]="bpp__Array__back"
bpp__TypedArray____vTable["all"]="bpp__Array__all"
bpp__TypedArray____vTable["empty"]="bpp__Array__empty"
bpp__TypedArray____vTable["slice"]="bpp__Array__slice"
bpp__TypedArray____vTable["clear"]="bpp__Array__clear"
bpp__TypedArray____vTable["set_type"]="bpp__TypedArray__set_type"
bpp__TypedArray____vTable["push"]="bpp__TypedArray__push"
bpp__TypedArray____vTable["insert"]="bpp__TypedArray__insert"
bpp__TypedArray____vTable["__copy"]="bpp__TypedArray____copy"
bpp__TypedArray____vTable["__delete"]="bpp__TypedArray____delete"
