#!/usr/bin/env bash
function bpp____repeat() {
	return $1
}
if {
! command -v flock &> /dev/null
}; then
>& 2 echo "Bash++: SharedObject requires the 'flock' command to be available."

exit 1

fi 
if {
! command -v chmod &> /dev/null
}; then
>& 2 echo "Bash++: SharedObject requires the 'chmod' command to be available."

exit 1

fi 
function bpp____initsupershell() {
	local bpp____supershellDirectory="/dev/shm/"
	if [[ ! -d "${bpp____supershellDirectory}" ]]; then
		bpp____supershellDirectory="${TMPDIR:-/tmp/}"
	fi
	local bpp____supershelltempfile="$(mktemp "${bpp____supershellDirectory}/XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX")"
	eval "exec {bpp____supershellFD__$BASHPID}<>\"$bpp____supershelltempfile\""
	rm "$bpp____supershelltempfile"
}
function bpp____supershell() {
	local __outputVar="$1" __command="$2" __supershellFD="bpp____supershellFD__$BASHPID" __temporaryStorage=""
	if [[ -z "${!__supershellFD}" ]]; then
		bpp____initsupershell
	else
		__temporaryStorage=$(< "/dev/fd/${!__supershellFD}")
	fi
	$__command 1>"/dev/fd/${!__supershellFD}"
	eval "$__outputVar=\$(< "/dev/fd/${!__supershellFD}")"
	echo "${__temporaryStorage}">"/dev/fd/${!__supershellFD}"
}
function bpp____dynamic__cast() {
	local __type="$1" __outputVar="$2" __this="$3"
	([[ -z "${__outputVar}" ]]) && >&2 echo "Bash++: Error: Invalid dynamic_cast" && exit 1
	eval "${__outputVar}=0"
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vTable="${__this}____vPointer"
	if ! eval "declare -p \"${__vTable}\"" &>/dev/null; then
		return 1
	fi
	while [[ ! -z "${!__vTable}" ]] 2>/dev/null; do
		[[ "${!__vTable}" == "bpp__${__type}____vTable" ]] && eval "${__outputVar}=\"${__this}\"" && return 0
		__vTable="${!__vTable}[\"__parent__\"]"
	done
	return 1
}
function bpp__SharedObject__toPrimitive() {
	local __this="$1"
	shift 1
	
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @SharedObject.toPrimitive on null object"
		return 1
	fi

	echo SharedObject Instance

}
function bpp__SharedObject__setEncrypted() {
	local __this="$1"
	shift 1
	local value="$1"
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @SharedObject.setEncrypted on null object"
		return 1
	fi

if {
local __this__used=${__this}__used

[[ ${!__this__used} -ne 0 ]]
____ret=$?
unset __this__used

bpp____repeat $____ret
}; then
>& 2 echo "Error: SharedObject: Cannot change encryption setting after the array has been used."

return 1

fi 
if {
[[ "$value" == "1" || "$value" == "true" ]]
}; then
if {
! command -v openssl &> /dev/null
}; then
>& 2 echo "Bash++: SharedObject encryption requires the 'openssl' command to be available."

return 1

fi 
local __this__encrypted=${__this}__encrypted
____assignment0=1

eval ${__this__encrypted}=\$____assignment0

____ret=$?
unset __this__encrypted
unset ____assignment0

bpp____repeat $____ret
else
local __this__encrypted=${__this}__encrypted
____assignment1=0

eval ${__this__encrypted}=\$____assignment1

____ret=$?
unset __this__encrypted
unset ____assignment1

bpp____repeat $____ret
fi 

}
function bpp__SharedObject___lock() {
	local __this="$1"
	shift 1
	
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @SharedObject._lock on null object"
		return 1
	fi

local __this__fd_variable_name=${__this}__fd_variable_name

local fd=${!__this__fd_variable_name}
____ret=$?
unset __this__fd_variable_name

bpp____repeat $____ret
if {
[[ ! -v ${fd} ]]
}; then
local __this__object_file=${__this}__object_file

eval "exec {${fd}}<>\"${!__this__object_file}\""
____ret=$?
unset __this__object_file

bpp____repeat $____ret
eval "flock -x \"${!fd}\""

else
return 1

fi 

}
function bpp__SharedObject___unlock() {
	local __this="$1"
	shift 1
	
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @SharedObject._unlock on null object"
		return 1
	fi

local __this__fd_variable_name=${__this}__fd_variable_name

local fd=${!__this__fd_variable_name}
____ret=$?
unset __this__fd_variable_name

bpp____repeat $____ret
if {
{
[[ -v ${fd} ]]
} && {
local __this__extended_lock=${__this}__extended_lock

[[ ${!__this__extended_lock} -eq 0 ]]
____ret=$?
unset __this__extended_lock

bpp____repeat $____ret
}
}; then
eval "flock -u \"${!fd}\""

eval "exec {${fd}}>&-"

eval "unset ${fd}"

else
return 1

fi 

}
function bpp__SharedObject__lock() {
	local __this="$1"
	shift 1
	
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @SharedObject.lock on null object"
		return 1
	fi

if {
bpp__SharedObject___lock ${__this}
}; then
local __this__extended_lock=${__this}__extended_lock
____assignment2=1

eval ${__this__extended_lock}=\$____assignment2

____ret=$?
unset __this__extended_lock
unset ____assignment2

bpp____repeat $____ret
else
return 1

fi 

}
function bpp__SharedObject__unlock() {
	local __this="$1"
	shift 1
	
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @SharedObject.unlock on null object"
		return 1
	fi

if {
local __this__extended_lock=${__this}__extended_lock

[[ ${!__this__extended_lock} -eq 1 ]]
____ret=$?
unset __this__extended_lock

bpp____repeat $____ret
}; then
local __this__extended_lock=${__this}__extended_lock
____assignment3=0

eval ${__this__extended_lock}=\$____assignment3

____ret=$?
unset __this__extended_lock
unset ____assignment3

bpp____repeat $____ret
bpp__SharedObject___unlock ${__this}

else
return 1

fi 

}
function bpp__SharedObject____constructor() {
	local __this="$1"
	shift 1
	
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @SharedObject.__constructor on null object"
		return 1
	fi

local __this__object_file=${__this}__object_file
function ____supershellRunFunc0() {
	mktemp
}
bpp____supershell ____supershellOutput0 ____supershellRunFunc0
____assignment4=${____supershellOutput0}

eval ${__this__object_file}=\$____assignment4

____ret=$?
unset __this__object_file
unset -f ____supershellRunFunc0
unset ____supershellOutput0
unset ____assignment4

bpp____repeat $____ret
local __this__object_file=${__this}__object_file

chmod 600 "${!__this__object_file}"
____ret=$?
unset __this__object_file

bpp____repeat $____ret
local __this__encryption_key=${__this}__encryption_key
function ____supershellRunFunc1() {
	head -c 32 /dev/urandom | base64 -w0
}
bpp____supershell ____supershellOutput1 ____supershellRunFunc1
____assignment5=${____supershellOutput1}

eval ${__this__encryption_key}=\$____assignment5

____ret=$?
unset __this__encryption_key
unset -f ____supershellRunFunc1
unset ____supershellOutput1
unset ____assignment5

bpp____repeat $____ret
local fdvar

while :; do
fdvar="BPP__SHAREDOBJECT__LOCKFD__$RANDOM$RANDOM$RANDOM$RANDOM"

{
[[ ! -v ${fdvar} ]]
} && {
break
}


done
local __this__fd_variable_name=${__this}__fd_variable_name
____assignment6="$fdvar"

eval ${__this__fd_variable_name}=\$____assignment6

____ret=$?
unset __this__fd_variable_name
unset ____assignment6

bpp____repeat $____ret

}
function bpp__SharedObject____destructor() {
	local __this="$1"
	shift 1
	
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @SharedObject.__destructor on null object"
		return 1
	fi

if {
local __this__object_file=${__this}__object_file

[[ -f "${!__this__object_file}" ]]
____ret=$?
unset __this__object_file

bpp____repeat $____ret
}; then
bpp__SharedObject___lock ${__this}

local __this__object_file=${__this}__object_file

rm -f "${!__this__object_file}" 2> /dev/null
____ret=$?
unset __this__object_file

bpp____repeat $____ret
bpp__SharedObject___unlock ${__this}

fi 

}
function bpp__SharedObject____copy() {
	local __this="$1"
	shift 1
	local __copyFromPtr="$1"
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @SharedObject.__copy on null object"
		return 1
	fi

bpp____dynamic__cast "SharedObject" "__dynamicCast0" __copyFromPtr
__copyFromPtr=${__dynamicCast0}
unset __dynamicCast0
if [[ ${__copyFromPtr} == 0 ]]; then
	>&2 echo "Bash++: Error: SharedObject: Attempted to copy between incompatible types."
	return 1
fi

	local ____copyFromPtr__object_file="${__copyFromPtr}__object_file"
	eval "${__this}__object_file=\${!____copyFromPtr__object_file}"


	local ____copyFromPtr__encrypted="${__copyFromPtr}__encrypted"
	eval "${__this}__encrypted=\${!____copyFromPtr__encrypted}"


	local ____copyFromPtr__encryption_key="${__copyFromPtr}__encryption_key"
	eval "${__this}__encryption_key=\${!____copyFromPtr__encryption_key}"


	local ____copyFromPtr__extended_lock="${__copyFromPtr}__extended_lock"
	eval "${__this}__extended_lock=\${!____copyFromPtr__extended_lock}"


	local ____copyFromPtr__used="${__copyFromPtr}__used"
	eval "${__this}__used=\${!____copyFromPtr__used}"


	local ____copyFromPtr__fd_variable_name="${__copyFromPtr}__fd_variable_name"
	eval "${__this}__fd_variable_name=\${!____copyFromPtr__fd_variable_name}"


}
function bpp__SharedObject____new() {
	local __this="$1"
	shift 1
	
	
if [[ "${__this}" == "" ]]; then
	while : ; do
		__this="bpp__SharedObject__$RANDOM$RANDOM$RANDOM$RANDOM"
		local __unusedVar="${__this}____vPointer"
		[[ -z "${!__unusedVar+x}" ]] && break
	done
fi
	eval "${__this}____vPointer=bpp__SharedObject____vTable"

	local __objAssignment=
	eval "${__this}__object_file=\$__objAssignment"
	unset __objAssignment


	local __objAssignment=0
	eval "${__this}__encrypted=\$__objAssignment"
	unset __objAssignment


	local __objAssignment=
	eval "${__this}__encryption_key=\$__objAssignment"
	unset __objAssignment


	local __objAssignment=0
	eval "${__this}__extended_lock=\$__objAssignment"
	unset __objAssignment


	local __objAssignment=0
	eval "${__this}__used=\$__objAssignment"
	unset __objAssignment


	local __objAssignment=
	eval "${__this}__fd_variable_name=\$__objAssignment"
	unset __objAssignment



echo "${__this}"

}
function bpp__SharedObject____delete() {
	local __this="$1"
	shift 1
	
	while : ; do
		if ! eval "declare -p \"${__this}\"" &>/dev/null; then
			break
		fi
		[[ -z "${!__this}" ]] && break
		__this="${!__this}"
	done
	local __vPointer="${__this}____vPointer"
	if [[ "${__this}" == "0" ]] || [[ -z "${!__vPointer}" ]]; then
		>&2 echo "Bash++: Error: Attempted to call @SharedObject.__delete on null object"
		return 1
	fi


unset "${__this}__object_file"
unset "${__this}__encrypted"
unset "${__this}__encryption_key"
unset "${__this}__extended_lock"
unset "${__this}__used"
unset "${__this}__fd_variable_name"
unset "${__this}____vPointer"

}
declare -A bpp__SharedObject____vTable
bpp__SharedObject____vTable["toPrimitive"]="bpp__SharedObject__toPrimitive"
bpp__SharedObject____vTable["__destructor"]="bpp__SharedObject____destructor"
bpp__SharedObject____vTable["__copy"]="bpp__SharedObject____copy"
bpp__SharedObject____vTable["__delete"]="bpp__SharedObject____delete"

