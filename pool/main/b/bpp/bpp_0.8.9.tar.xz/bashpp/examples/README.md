# Bash++ Scripts

This directory contains some example scripts that demonstrate how to use Bash++.

More detailed descriptions of the language can be found at the [website](https://bpp.sh/language.html).

 - [toprimitive.bpp](toprimitive.bpp) - Demonstrates how to use **.toPrimitive** methods

 - [constructors-and-destructors.bpp](constructors-and-destructors.bpp) - Demonstrates how to use **constructors** and **destructors**

 - [supershell.bpp](supershell.bpp) - Demonstrates how to use Bash++ **supershells**

 - [include.bpp](include.bpp) - Demonstrates how to use the **include** directive

 - [inheritance.bpp](inheritance.bpp) - Demonstrates **inheritance** and **polymorphism** in Bash++

 - [pointers.bpp](pointers.bpp) - Demonstrates how to use **pointers** in Bash++

 - [queue.bpp](queue.bpp) - A small example of a **queue** implemented in Bash++ using pointers

 - [stack.bpp](stack.bpp) - A small example of a **stack** implemented in Bash++

&nbsp;

 - [json.bpp](json.bpp) - A demonstration of more **advanced** usage of Bash++: a wrapper around `jq` for easy JSON manipulation, and an illustration of advanced method chaining techniques and dynamic command execution.
