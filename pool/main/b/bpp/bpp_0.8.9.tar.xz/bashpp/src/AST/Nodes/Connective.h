/**
 * Copyright (C) 2025 Andrew S. Rightenburg
 * Bash++: Bash with classes
 * Licensed under the GNU General Public License v3.0 or later (GPL-3.0-or-later)
 */

#pragma once

#include <AST/ASTNode.h>

namespace AST {

class Connective : public ASTNode {
	public:
		enum class ConnectiveType : uint8_t {
			AND,
			OR
		};
	protected:
		ConnectiveType m_TYPE;
	public:
		static constexpr AST::NodeType static_type = AST::NodeType::Connective;
		constexpr AST::NodeType getType() const override { return static_type; }

		ConnectiveType TYPE() const {
			return m_TYPE;
		}
		void setType(ConnectiveType type) {
			m_TYPE = type;
		}

		std::ostream& prettyPrint(std::ostream& os, size_t indentation_level = 0) const override {
			std::string indent(indentation_level * PRETTYPRINT_INDENTATION_AMOUNT, ' ');
			os << indent << "(Connective "
				<< (m_TYPE == ConnectiveType::AND ? "&&" : "||")
				<< ")";
			return os;
		}
};

} // namespace AST
