/**
 * Copyright (C) 2025 Andrew S. Rightenburg
 * Bash++: Bash with classes
 * Licensed under the GNU General Public License v3.0 or later (GPL-3.0-or-later)
 */

#pragma once

#include <AST/ASTNode.h>

namespace AST {

class ObjectReference : public ASTNode {
	protected:
		AST::Token<std::string> m_IDENTIFIER;
		std::vector<AST::Token<std::string>> m_IDENTIFIERS;
		bool m_has_hashkey = false;
		bool m_lvalue = false;
		bool m_self_reference = false;
		bool m_ptr_dereference = false;
		bool m_address_of = false;
	public:
		static constexpr AST::NodeType static_type = AST::NodeType::ObjectReference;
		constexpr AST::NodeType getType() const override { return static_type; }

		void setIdentifier(const AST::Token<std::string>& identifier) {
			m_IDENTIFIER = identifier;
		}
		const AST::Token<std::string>& IDENTIFIER() const {
			return m_IDENTIFIER;
		}

		void addIdentifier(const AST::Token<std::string>& identifier) {
			m_IDENTIFIERS.push_back(identifier);
		}
		const std::vector<AST::Token<std::string>>& IDENTIFIERS() const {
			return m_IDENTIFIERS;
		}

		void setHasHashkey(bool has_hashkey) {
			m_has_hashkey = has_hashkey;
		}
		bool hasHashkey() const {
			return m_has_hashkey;
		}

		void setLvalue(bool lvalue) {
			m_lvalue = lvalue;
		}
		bool isLvalue() const {
			return m_lvalue;
		}

		void setSelfReference(bool self_reference) {
			m_self_reference = self_reference;
		}
		bool isSelfReference() const {
			return m_self_reference;
		}

		void setPointerDereference(bool ptr_dereference) {
			m_ptr_dereference = ptr_dereference;
		}
		bool isPointerDereference() const {
			return m_ptr_dereference;
		}

		void setAddressOf(bool address_of) {
			m_address_of = address_of;
		}
		bool isAddressOf() const {
			return m_address_of;
		}

		std::ostream& prettyPrint(std::ostream& os, size_t indentation_level = 0) const override {
			std::string indent(indentation_level * PRETTYPRINT_INDENTATION_AMOUNT, ' ');
			os << indent << "(ObjectReference ["
				<< (m_lvalue ? "lvalue" : "rvalue")
				<< (m_self_reference ? ", self" : "")
				<< "]\n"
				<< indent << "  "
				<< (m_address_of ? "&" : "")
				<< (m_ptr_dereference ? "*" : "")
				<< "@";

			if (m_has_hashkey) {
				os << "#";
			}

			os << m_IDENTIFIER;
			for (const auto& id : m_IDENTIFIERS) {
				os << "." << id;
			}

			for (const auto& child : children) {
				os << std::endl;
				child->prettyPrint(os, indentation_level + 1);
			}
			os << ")" << std::flush;
			return os;
		}
};

} // namespace AST
