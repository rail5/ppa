/**
 * Copyright (C) 2025 Andrew S. Rightenburg
 * Bash++: Bash with classes
 * Licensed under the GNU General Public License v3.0 or later (GPL-3.0-or-later)
 */

#pragma once

#include <AST/ASTNode.h>
#include <AST/Nodes/StringType.h>

namespace AST {

/**
 * @class BashArithmeticForCondition
 * @brief Represents the condition part of a Bash arithmetic for loop
 * E.g., in for (( i=0; i<10; i++ )), the entire "(( i=0; i<10; i++ ))" would be represented by a BashArithmeticForCondition node.
 * Each of the three components would be represented by BashArithmeticStatement nodes as its children.
 * 
 */
class BashArithmeticForCondition : public StringType {
	public:
		static constexpr AST::NodeType static_type = AST::NodeType::BashArithmeticForCondition;
		constexpr AST::NodeType getType() const override { return static_type; }

		std::ostream& prettyPrint(std::ostream& os, size_t indentation_level = 0) const override {
			std::string indent(indentation_level * PRETTYPRINT_INDENTATION_AMOUNT, ' ');
			os << indent << "(BashArithmeticForCondition ((";
			for (const auto& child : children) {
				os << std::endl;
				child->prettyPrint(os, indentation_level + 1);
			}
			os << ")) )" << std::flush;
			return os;
		}
};

} // namespace AST
