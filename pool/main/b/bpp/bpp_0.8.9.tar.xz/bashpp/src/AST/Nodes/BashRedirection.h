/**
 * Copyright (C) 2025 Andrew S. Rightenburg
 * Bash++: Bash with classes
 * Licensed under the GNU General Public License v3.0 or later (GPL-3.0-or-later)
 */

#pragma once

#include <AST/ASTNode.h>
#include <AST/Nodes/StringType.h>

namespace AST {

class BashRedirection : public StringType {
	protected:
		AST::Token<std::string> m_OPERATOR;
	public:
		static constexpr AST::NodeType static_type = AST::NodeType::BashRedirection;
		constexpr AST::NodeType getType() const override { return static_type; }

		const AST::Token<std::string>& OPERATOR() const {
			return m_OPERATOR;
		}
		void setOperator(const AST::Token<std::string>& op) {
			m_OPERATOR = op;
		}

		std::ostream& prettyPrint(std::ostream& os, size_t indentation_level = 0) const override {
			std::string indent(indentation_level * PRETTYPRINT_INDENTATION_AMOUNT, ' ');
			os << indent << "(BashRedirection " << m_OPERATOR;
			for (const auto& child : children) {
				os << std::endl;
				child->prettyPrint(os, indentation_level + 1);
			}
			os << ")" << std::flush;
			return os;
		}
};

} // namespace AST
