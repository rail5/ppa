/**
* Copyright (C) 2025 rail5
* Bash++: Bash with classes
* Licensed under the GNU General Public License v3.0 or later (GPL-3.0-or-later)
 */

#include "bpp.h"

namespace bpp {

void bpp_object_reference::set_reference_type(bpp::reference_type reference_type) {
	this->reference_type = reference_type;
}

void bpp_object_reference::set_array_index(const std::string& array_index) {
	this->array_index = array_index;
}

bpp::reference_type bpp_object_reference::get_reference_type() const {
	return reference_type;
}

std::string bpp_object_reference::get_array_index() const {
	return array_index;
}

bool bpp_object_reference::has_array_index() const {
	return !array_index.empty();
}

} // namespace bpp
