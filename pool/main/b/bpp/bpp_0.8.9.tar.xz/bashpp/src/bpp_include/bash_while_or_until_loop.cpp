/**
* Copyright (C) 2025 rail5
* Bash++: Bash with classes
* Licensed under the GNU General Public License v3.0 or later (GPL-3.0-or-later)
 */

#include "bpp.h"

namespace bpp {

void bash_while_or_until_loop::set_condition(std::shared_ptr<bpp::bash_while_or_until_condition> condition) {
	this->condition = std::move(condition);
}

std::shared_ptr<bpp::bash_while_or_until_condition> bash_while_or_until_loop::get_condition() const {
	return condition;
}

std::string bash_while_or_until_loop::get_code() const {
	return nextline_buffer;
}

std::string bash_while_or_until_loop::get_pre_code() const {
	std::shared_ptr<std::ostringstream> ss = std::dynamic_pointer_cast<std::ostringstream>(code);
	if (ss == nullptr) {
		return "";
	}
	return ss->str();
}

std::string bash_while_or_until_loop::get_post_code() const {
	return postline_buffer;
}

} // namespace bpp
