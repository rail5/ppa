/**
* Copyright (C) 2025 rail5
* Bash++: Bash with classes
* Licensed under the GNU General Public License v3.0 or later (GPL-3.0-or-later)
 */

#include "bpp.h"

namespace bpp {

void bpp_object::set_class(std::shared_ptr<bpp_class> object_class) {
	this->type = object_class;
}

void bpp_object::set_pointer(bool is_pointer) {
	m_is_pointer = is_pointer;
}

void bpp_object::set_address(const std::string& address) {
	this->address = address;
}

void bpp_object::set_assignment_value(const std::string& assignment_value) {
	this->assignment_value = assignment_value;
}

void bpp_object::set_pre_access_code(const std::string& pre_access_code) {
	this->pre_access_code = pre_access_code;
}

void bpp_object::set_post_access_code(const std::string& post_access_code) {
	this->post_access_code = post_access_code;
}

void bpp_object::set_nullptr() {
	if (m_is_pointer) {
		assignment_value = bpp::bpp_nullptr;
	}
}

std::string bpp_object::get_address() const {
	return address;
}

std::string bpp_object::get_assignment_value() const {
	return assignment_value;
}

std::string bpp_object::get_pre_access_code() const {
	return pre_access_code;
}

std::string bpp_object::get_post_access_code() const {
	return post_access_code;
}

bool bpp_object::is_pointer() const {
	return m_is_pointer;
}

std::shared_ptr<bpp::bpp_object> bpp_object::get_copy_from() const {
	return copy_from;
}

} // namespace bpp
