/*
 * Copyright (C) 2025 Andrew S. Rightenburg
 * Bash++: Bash with classes
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

#pragma once

#include <stack>
#include <cassert>

#ifndef YY_TYPEDEF_YY_SCANNER_T
#define YY_TYPEDEF_YY_SCANNER_T
using yyscan_t = void*;
#endif

/**
 * @class ModeStack
 * @brief A stack to manage lexer modes for the Bash++ lexer.
 * 
 */
class ModeStack {
	private:
		std::stack<int> modeStack;
		yyscan_t relevant_lexer = nullptr;

		bool inSync() const;
	public:
		void bind(yyscan_t lexer);
		void push(int mode);
		void pop();
		void clear();
		int top() const;
		bool empty() const;
		size_t size() const;
};
