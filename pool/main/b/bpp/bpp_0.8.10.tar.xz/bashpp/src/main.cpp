/*
 * Copyright (C) 2025 Andrew S. Rightenburg
 * Bash++: Bash with classes
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

/*! \mainpage
 * \section intro_sec Introduction
 *
 * src/main.cpp is not necessarily the best introduction to the compiler's code.
 * 
 * Here is an article which gives an overview of the compiler:
 * 
 * [How Does the Bash++ Compiler Work?](https://log.bpp.sh/2026/01/25/how-does-the-bashpp-compiler-work.html)
 *
 * As for the rest, the Doxygen documentation will provide details on the compiler's different classes and functions.
*/

#include <iostream>
#include <fstream>
#include <filesystem>
#include <cstring>
#include <memory>
#include <unistd.h>
#include <cstdlib>

#include <version.h>
#include <updated_year.h>

#include <include/parse_arguments.h>
#include <AST/BashppParser.h>
#include <listener/BashppListener.h>

#include <error/InternalError.h>
#include <error/SyntaxError.h>

int main(int argc, char* argv[]) {
	std::shared_ptr<std::ostream> output_stream(&std::cout, [](std::ostream*){});
	std::shared_ptr<std::ostringstream> code_buffer = std::make_shared<std::ostringstream>();

	Arguments args;
	try {
		args = parse_arguments(argc, argv);
	} catch (const std::exception& e) {
		std::cerr << program_name << ": Error: " << e.what() << std::endl
			<< "Use -h for help" << std::endl;
		return 1;
	}

	if (args.exit_early()) return 0;

	if (args.output_to_file()) {
		output_stream = std::make_shared<std::ofstream>(args.output_file().value());
		if (!std::static_pointer_cast<std::ofstream>(output_stream)->is_open()) {
			std::cerr << program_name << ": Error: Could not open output file '" << args.output_file().value() << "'" << std::endl;
			return 1;
		}
	}

	// If the user didn't provide input, let them know, rather than just hang waiting for stdin
	if (args.input_from_stdin() && isatty(STDIN_FILENO)) {
		std::cerr << program_name << " " << bpp_compiler_version << std::endl
			<< help_intro << OptionParser.getHelpString();
		return 1;
	}

	std::string full_path_of_input_file = "<stdin>";
	if (!args.input_from_stdin()) {
		try {
			full_path_of_input_file = std::filesystem::canonical(args.input_file().value()).string();
		} catch (const std::filesystem::filesystem_error& e) {
			std::cerr << "Error: Could not get full path of source file '" << args.input_file().value() << "': " << e.what() << std::endl;
			return 1;
		}
	}

	AST::BashppParser parser;
	if (args.input_from_stdin()) {
		parser.setInputFromFilePtr(stdin, "<stdin>");
	} else {
		parser.setInputFromFilePath(full_path_of_input_file);
	}
	parser.setDisplayLexerOutput(args.display_tokens());
	
	auto program = parser.program();
	const auto& parser_errors = parser.get_errors();
	if (program == nullptr) {
		bpp::ErrorHandling::print_parser_errors(
			parser_errors,
			full_path_of_input_file,
			{},
			nullptr,
			false);
		std::cerr << program_name << ": Error: Failed to parse program." << std::endl;
		return 1;
	}

	if (args.display_parse_tree()) {
		// '-p' given, exit after displaying the parse tree
		std::cout << *program << std::endl;
		return 0;
	} else if (args.display_tokens()) {
		// '-t' given (lexer tokens displayed), exit now even if we didn't display the parse tree
		return 0;
	}

	if (args.run_on_exit()) {
		// Create a temporary file to store the program
		std::filesystem::path temp_path = std::filesystem::temp_directory_path() / "bashpp_temp_XXXXXX";
		std::string temp_file = temp_path.string();

		// mkstemp requires a mutable char array
		
		std::vector<char> temp_file_vec(temp_file.begin(), temp_file.end());
		temp_file_vec.push_back('\0'); // Null-terminate the string for mkstemp

		int fd = mkstemp(temp_file_vec.data());
		if (fd == -1) {
			std::cerr << program_name << ": Error: Could not create temporary file for output" << std::endl;
			return 1;
		}
		close(fd);

		std::shared_ptr<std::ofstream> ostream = std::make_shared<std::ofstream>(temp_file_vec.data());
		if (!ostream->is_open()) {
			std::cerr << program_name << ": Error: Could not open temporary file for output" << std::endl;
			return 1;
		}

		output_stream = std::static_pointer_cast<std::ostream>(ostream);
		args.set_output_file(std::string(temp_file_vec.data()));
	}

	std::unique_ptr<BashppListener> listener = std::make_unique<BashppListener>();
	listener->set_source_file(full_path_of_input_file);
	listener->set_include_paths(args.include_paths());
	listener->set_code_buffer(code_buffer);
	listener->set_output_stream(output_stream);
	listener->set_output_file(args.output_file().value_or(""));
	listener->set_run_on_exit(args.run_on_exit());
	listener->set_suppress_warnings(args.suppress_warnings());
	listener->set_target_bash_version(args.target_bash_version());
	listener->set_arguments(args.program_arguments());
	listener->set_parser_errors(parser_errors);

	try {
		// Walk the tree
		listener->walk(program);

	} catch (const bpp::ErrorHandling::InternalError& e) {
		std::cerr << "Internal error: " << e.what() << std::endl;
		return 1;
	} catch (const std::exception& e) {
		std::cerr << "Standard exception: " << e.what() << std::endl;
		// Output the type of the exception
		std::cerr << "Exception type: " << typeid(e).name() << std::endl;
		return 1;
	} catch (...) {
		std::cerr << "Unknown exception occurred" << std::endl;
		return 1;
	}

	return listener->get_exit_code();
}
