/*
 * Copyright (C) 2025 Andrew S. Rightenburg
 * Bash++: Bash with classes
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

#pragma once

#include <cstdint>

namespace AST {
enum class NodeType : uint8_t {
	Program = 0,
	ArrayAssignment,
	ArrayIndex,
	BashArithmeticForCondition,
	BashArithmeticForStatement,
	BashArithmeticStatement,
	BashArithmeticSubstitution,
	Bash53NativeSupershell,
	BashCaseInput,
	BashCasePattern,
	BashCasePatternHeader,
	BashCaseStatement,
	BashCommand,
	BashCommandSequence,
	BashForStatement,
	BashIfCondition,
	BashIfElseBranch,
	BashIfRootBranch,
	BashIfStatement,
	BashInCondition,
	BashPipeline,
	BashRedirection,
	BashSelectStatement,
	BashTestConditionCommand,
	BashUntilStatement,
	BashVariable,
	BashWhileOrUntilCondition,
	BashWhileStatement,
	BashFunction,
	Block,
	ClassDefinition,
	Connective,
	ConstructorDefinition,
	DatamemberDeclaration,
	DeleteStatement,
	DestructorDefinition,
	DoublequotedString,
	DynamicCast,
	DynamicCastTarget,
	HeredocBody,
	HereString,
	IncludeStatement,
	MethodDefinition,
	NewStatement,
	ObjectAssignment,
	ObjectInstantiation,
	ObjectReference,
	ParameterExpansion,
	PointerDeclaration,
	PrimitiveAssignment,
	ProcessSubstitution,
	RawSubshell,
	RawText,
	Rvalue,
	SubshellSubstitution,
	Supershell,
	TypeofExpression,
	ValueAssignment,
	ERROR_TYPE
};
} // namespace AST
