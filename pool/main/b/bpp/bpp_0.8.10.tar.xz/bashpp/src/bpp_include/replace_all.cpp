/*
 * Copyright (C) 2025 Andrew S. Rightenburg
 * Bash++: Bash with classes
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

#include <string>

#include "replace_all.h"

/**
 * @brief Replace all occurences of a substring in a string
 * @param str The string to search in
 * @param from The substring to search for
 * @param to The substring to replace with
 */
std::string replace_all(std::string str, const std::string& from, const std::string& to) {
	if (from.empty()) return str;
	size_t start_pos = 0;
	while ((start_pos = str.find(from, start_pos)) != std::string::npos) {
		str.replace(start_pos, from.length(), to);
		start_pos += to.length();
	}
	return str;
}
