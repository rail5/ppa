/*
 * Copyright (C) 2025 Andrew S. Rightenburg
 * Bash++: Bash with classes
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

#include "bpp.h"

namespace bpp {

/**
 * @brief Add a class to this entity's list of classes
 * @param class_ The class to add
 * @return true if the class was added, false if the class already exists
 */
bool bpp_entity::add_class(std::shared_ptr<bpp_class> class_) {
	std::string name = class_->get_name();
	if (classes.contains(name)) {
		return false;
	}
	classes[name] = class_;
	return true;
}

/**
 * @brief Add an object to this entity's list of objects
 * @param object The object to add
 * @return true if the object was added, false if the object already exists
 */
bool bpp_entity::add_object(std::shared_ptr<bpp_object> object, bool /* make_local */) {
	std::string name = object->get_name();
	if (local_objects.contains(name) || foreign_objects.contains(name)) return false;

	local_objects[name] = object;
	return true;
}

std::shared_ptr<bpp_class> bpp_entity::get_class() {
	return type.lock();
}

std::string bpp_entity::get_address() const {
	return "";
}

void bpp_entity::set_name(const std::string& name) {
	this->name = name;
}

std::string bpp_entity::get_name() const {
	return this->name;
}

/**
 * @brief Get the class which contains this entity
 * 
 * Useful in many cases, for example in the event that this entity is a method of a particular class
 */
std::weak_ptr<bpp::bpp_class> bpp_entity::get_containing_class() {
	return containing_class;
}

std::weak_ptr<bpp::bpp_program> bpp_entity::get_containing_program() {
	return containing_program;
}

bool bpp_entity::set_containing_class(std::weak_ptr<bpp::bpp_class> containing_class) {
	this->containing_class = std::move(containing_class);
	return true;
}

void bpp_entity::set_definition_position(const std::string& file, uint64_t line, uint64_t column) {
	initial_definition = bpp::SymbolPosition(file, line, column);
	references.emplace_front(file, line, column); // Set the definition as the entity's first reference
}

bpp::SymbolPosition bpp_entity::get_initial_definition() const {
	return initial_definition;
}

void bpp_entity::add_reference(const std::string& file, uint64_t line, uint64_t column) {
	references.emplace_back(file, line, column);
	// If this is a derived class's version of an overridden method, add the reference to the overridden method as well
	// This is useful in the language server for "find all references" functionality,
	// And, for example, for "rename symbol" -- renaming the original method should rename all overridden versions as well
	auto _overriden_method = overridden_method.lock();
	if (_overriden_method) {
		_overriden_method->add_reference(file, line, column);
	}
}

std::list<bpp::SymbolPosition> bpp_entity::get_references() const {
	return references;
}

/**
 * @brief Inherit from a parent entity
 * 
 * This function copies all classes and objects from the parent entity into this entity.
 * 
 * @param parent The parent entity to inherit from
 */
void bpp_entity::inherit(std::shared_ptr<bpp_entity> parent) {
	const auto& parent_classes = parent->get_classes();
	const auto& parent_foreign_objects = parent->get_foreign_objects();
	const auto& parent_owned_objects = parent->get_local_objects();

	classes.reserve(classes.size() + parent_classes.size());
	foreign_objects.reserve(foreign_objects.size() + parent_foreign_objects.size() + parent_owned_objects.size());

	std::copy(parent_classes.begin(), parent_classes.end(), std::inserter(classes, classes.end()));

	// Note that we copy both foreign and owned objects into the 'objects' map of this entity.
	// Objects owned by the parent entity are foreign to *this* entity
	std::copy(parent_foreign_objects.begin(), parent_foreign_objects.end(), std::inserter(foreign_objects, foreign_objects.end()));
	std::copy(parent_owned_objects.begin(), parent_owned_objects.end(), std::inserter(foreign_objects, foreign_objects.end()));
}

void bpp_entity::inherit(std::shared_ptr<bpp_program> program) {
	containing_program = program;
	inherit(std::static_pointer_cast<bpp_entity>(program));
}

void bpp_entity::inherit(std::shared_ptr<bpp_class> parent) {
	// If we have no `containing_program`, inherit it from the parent class
	if (containing_program.expired()) {
		auto parent_program = parent->get_containing_program().lock();
		containing_program = parent_program;
	}
	inherit(std::static_pointer_cast<bpp_entity>(parent));
}

const std::unordered_map<std::string, std::weak_ptr<bpp_class>>& bpp_entity::get_classes() const {
	return classes;
}

const std::unordered_map<std::string, std::weak_ptr<bpp_object>>& bpp_entity::get_foreign_objects() const {
	return foreign_objects;
}

const std::unordered_map<std::string, std::shared_ptr<bpp_object>>& bpp_entity::get_local_objects() const {
	return local_objects;
}

std::shared_ptr<bpp::bpp_class> bpp_entity::get_class(const std::string& name) {
	auto it = classes.find(name);
	if (it != classes.end()) {
		return it->second.lock();
	}

	return nullptr;
}

std::shared_ptr<bpp::bpp_object> bpp_entity::get_object(const std::string& name) {
	if (local_objects.contains(name)) {
		return local_objects[name];
	}

	if (foreign_objects.contains(name)) {
		return foreign_objects[name].lock();
	}

	return nullptr;
}

std::shared_ptr<bpp::bpp_class> bpp_entity::get_parent() const {
	if (!parents.empty()) {
		return parents.back().lock();
	}

	return nullptr;
}

} // namespace bpp
