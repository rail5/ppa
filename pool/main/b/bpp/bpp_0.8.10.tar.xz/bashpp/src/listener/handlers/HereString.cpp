/*
 * Copyright (C) 2025 Andrew S. Rightenburg
 * Bash++: Bash with classes
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

#include <listener/BashppListener.h>

void BashppListener::enterHereString(std::shared_ptr<AST::HereString> node) {
	std::shared_ptr<bpp::bpp_code_entity> current_code_entity = std::dynamic_pointer_cast<bpp::bpp_code_entity>(entity_stack.top());
	if (current_code_entity == nullptr) {
		throw bpp::ErrorHandling::SyntaxError(this, node, "HereString outside of a code entity");
	}

	std::shared_ptr<bpp::bpp_string> herestring_entity = std::make_shared<bpp::bpp_string>();
	herestring_entity->set_containing_class(current_code_entity->get_containing_class());
	herestring_entity->inherit(current_code_entity);

	entity_stack.push(herestring_entity);
}

void BashppListener::exitHereString(std::shared_ptr<AST::HereString> /*node*/) {
	bpp_assert(topmost_entity_is<bpp::bpp_string>(), "Herestring entity not found in the entity stack");
	auto herestring_entity = std::static_pointer_cast<bpp::bpp_string>(entity_stack.top());

	entity_stack.pop();

	bpp_assert(topmost_entity_is<bpp::bpp_code_entity>(), "Current code entity not found in the entity stack");
	auto current_code_entity = std::static_pointer_cast<bpp::bpp_code_entity>(entity_stack.top());

	current_code_entity->add_code_to_previous_line(herestring_entity->get_pre_code());
	current_code_entity->add_code_to_next_line(herestring_entity->get_post_code());
	current_code_entity->add_code("<<<" + herestring_entity->get_code(), false);
}
