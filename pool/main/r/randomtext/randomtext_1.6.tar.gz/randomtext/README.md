# randomtext
Outputs printable ASCII from /dev/urandom
