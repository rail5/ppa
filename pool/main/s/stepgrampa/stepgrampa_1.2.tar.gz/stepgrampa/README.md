# stepgrampa
Replaces MATE's **engrampa** with GNOME's **file-roller** for use in Caja and the MATE desktop

## Why?
My reasoning:

  - **file-roller** can create more archive types than **engrampa** can (including, for example, ISOs)
  
  - I prefer the MATE desktop, and want to be able to use the "Compress" context menu option in Caja for this
